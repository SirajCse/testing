@extends('layouts/contentLayoutHideNavbar')

@section('title', 'Edit Lab Report')

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/all.dataTables.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/ui/jquery-ui.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection

@section('page-style')
    <style>
        /* ═══════════════════════════════════════════════
           COMPONENT TABLE — WRAPPER
           ═══════════════════════════════════════════════ */
        .component-wrap {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .component-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 1.08rem;
            color: #0f0f15;
            table-layout: fixed;
        }
        .component-table th {
            background: #eef0f7;
            font-weight: 700;
            font-size: .86rem;
            text-transform: uppercase;
            letter-spacing: .35px;
            padding: 6px 8px;
            text-align: left;
            color: #0f0f15;
            border-bottom: 2px solid #cfd2dc;
            white-space: nowrap;
        }
        .component-table td {
            padding: 3px 8px;
            border-bottom: 1px solid #e6e8f0;
            vertical-align: middle;
            font-size: 1.08rem;
            line-height: 1.3;
            color: #0f0f15;
            word-break: break-word;
        }
        .component-table tbody tr:hover td { background: #f7f8fd; }

        .component-table                .col-sl     { width: 3%;  text-align: center; font-weight: 700; }
        .component-table                .col-hide   { width: 5%;  text-align: center; }
        .component-table                .col-name   { width: 20%; font-weight: 700; }
        .component-table                .col-result { width: 24%; }
        .component-table                .col-unit   { width: 10%; }
        .component-table                .col-ref    { width: 17%; font-size: .88rem; line-height: 1.25; }
        .component-table                .col-status { width: 10%; }
        .component-table                .col-color  { width: 11%; text-align: center; }

        .component-table.no-color       .col-name   { width: 22%; }
        .component-table.no-color       .col-result { width: 26%; }
        .component-table.no-color       .col-unit   { width: 12%; }
        .component-table.no-color       .col-ref    { width: 22%; }
        .component-table.no-color       .col-status { width: 10%; }

        .component-table.no-status      .col-name   { width: 22%; }
        .component-table.no-status      .col-result { width: 26%; }
        .component-table.no-status      .col-unit   { width: 12%; }
        .component-table.no-status      .col-ref    { width: 20%; }
        .component-table.no-status      .col-color  { width: 12%; }

        .component-table.no-status.no-color .col-name   { width: 24%; }
        .component-table.no-status.no-color .col-result { width: 30%; }
        .component-table.no-status.no-color .col-unit   { width: 14%; }
        .component-table.no-status.no-color .col-ref    { width: 24%; }

        .hide-check {
            width: 18px;
            height: 18px;
            accent-color: #7367f0;
            cursor: pointer;
        }

        .table-input,
        .table-select,
        .table-textarea {
            width: 100%;
            min-width: 0;
            padding: 5px 9px;
            border: 1px solid #c5c8d4;
            border-radius: 6px;
            font-size: 1.2rem;
            font-family: inherit;
            color: #0f0f15;
            background: #fff;
            transition: .15s;
        }
        .table-input::placeholder,
        .table-textarea::placeholder { color: #a0a3b1; }

        .table-input:focus,
        .table-select:focus,
        .table-textarea:focus {
            background: #fffbe6;
            border-color: #7367f0;
            box-shadow: 0 0 0 3px rgba(115,103,240,.2);
            outline: none;
        }
        .table-textarea {
            resize: vertical;
            min-height: 44px;
            font-size: 1rem;
            padding: 5px 9px;
        }

        .ref-text {
            display: inline-block;
            max-width: 100%;
            background: #f5f6fc;
            padding: 2px 8px;
            border-radius: 5px;
            border-left: 3px solid #c9c4fb;
            font-size: .88rem;
            line-height: 1.3;
            color: #0f0f15;
            word-break: break-word;
        }

        .ref-picker { display: flex; flex-direction: column; gap: 4px; }

        .ref-picker .ref-display {
            cursor: pointer;
            display: inline-block;
            max-width: 100%;
            padding: 2px 8px;
            border-radius: 5px;
            background: #f5f6fc;
            border-left: 3px solid #c9c4fb;
            font-size: .88rem;
            line-height: 1.3;
            color: #0f0f15;
            word-break: break-word;
            transition: .15s;
        }
        .ref-picker .ref-display:hover {
            background: #e8e6ff;
            border-left-color: #7367f0;
        }
        .ref-picker .ref-display:empty::before {
            content: '—';
            color: #a0a3b1;
        }

        .ref-picker .ref-editor {
            width: 100%;
            padding: 4px 6px;
            border: 1px solid #7367f0;
            border-radius: 6px;
            font-size: .82rem;
            font-weight: 600;
            color: #0f0f15;
            background: #fffbe6;
            outline: none;
            box-shadow: 0 0 0 3px rgba(115,103,240,.18);
        }

        .ref-select {
            width: 100%;
            padding: 4px 6px;
            border: 1px solid #c5c8d4;
            border-radius: 6px;
            font-size: .82rem;
            font-weight: 600;
            color: #0f0f15;
            background: #fff;
        }
        .ref-select:focus {
            border-color: #7367f0;
            box-shadow: 0 0 0 3px rgba(115,103,240,.18);
            outline: none;
        }
        .ref-free { font-size: .82rem; }

        .status-input {
            width: 100%;
            min-width: 0;
            padding: 4px 6px;
            border: 1px solid #d0d3df;
            border-radius: 5px;
            font-size: .82rem;
            font-weight: 600;
            color: #0f0f15;
            background: #fff;
            text-align: center;
        }
        .status-input::placeholder { color: #c0c3cf; font-weight: 400; }
        .status-input:focus {
            background: #fffbe6;
            border-color: #7367f0;
            box-shadow: 0 0 0 3px rgba(115,103,240,.2);
            outline: none;
        }

        .color-cell-wrap {
            display: flex;
            align-items: center;
            gap: 4px;
            justify-content: center;
        }
        .color-swatch {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            border: 2px solid #fff;
            box-shadow: 0 0 0 1px #cfd2dc, 0 1px 3px rgba(0,0,0,.12);
            flex-shrink: 0;
            transition: .15s;
        }
        .color-swatch.empty {
            background: transparent !important;
            box-shadow: 0 0 0 1px #d0d3df inset;
            border: 2px dashed #d0d3df;
        }
        .color-select {
            flex: 1;
            min-width: 0;
            padding: 3px 2px;
            border: 1px solid #d0d3df;
            border-radius: 5px;
            font-size: .7rem;
            font-weight: 600;
            color: #0f0f15;
            background: #fff;
            cursor: pointer;
            transition: .15s;
        }
        .color-select:hover { border-color: #7367f0; }
        .color-select:focus {
            background: #fffbe6;
            border-color: #7367f0;
            box-shadow: 0 0 0 3px rgba(115,103,240,.2);
            outline: none;
        }

        .culture-input-group {
            display: flex;
            gap: 6px;
            align-items: stretch;
            min-width: 0;
        }
        .culture-input-group .culture-mic,
        .culture-input-group .culture-zone {
            flex: 1 1 0;
            min-width: 35px;
            text-align: center;
            font-weight: 600;
            transition: .15s;
        }

        .culture-input-group .culture-mic.is-default,
        .culture-input-group .culture-zone.is-default {
            color: #6b7280;
            font-style: italic;
            background: #f9fafb;
        }
        .culture-input-group .culture-mic.is-default:focus,
        .culture-input-group .culture-zone.is-default:focus {
            font-style: normal;
            color: #0f0f15;
            background: #fffbe6;
        }

        .culture-interp {
            flex: 0 0 78px;
            min-width: 78px;
            padding: 5px 8px;
            border: 1.5px solid #c5c8d4;
            border-radius: 6px;
            font-size: 1.05rem;
            font-weight: 800;
            text-align: center;
            text-align-last: center;
            cursor: pointer;
            background: #fff;
        }
        .culture-interp:focus {
            outline: none;
            border-color: #7367f0;
            box-shadow: 0 0 0 3px rgba(115,103,240,.18);
        }
        .culture-interp.interp-s  { background:#d4edda; color:#0d6b3f; border-color:#a7f3d0; }
        .culture-interp.interp-i  { background:#fff3cd; color:#856404; border-color:#ffe69c; }
        .culture-interp.interp-r  { background:#f8d7da; color:#842029; border-color:#fecaca; }
        .culture-interp.interp-nt { background:#e9ecef; color:#6c757d; border-color:#ced4da; }

        .hide-all-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            font-size: .82rem;
            font-weight: 600;
            border-radius: 22px;
            border: 1px solid #c5c8d4;
            background: #fff;
            color: #0f0f15;
            cursor: pointer;
            transition: .15s;
            white-space: nowrap;
        }
        .hide-all-btn:hover  { background: #eef0f7; border-color: #7367f0; color: #7367f0; }
        .hide-all-btn.active { background: #e8e6ff; border-color: #7367f0; color: #7367f0; }

        .row-title td {
            background: #eef0f7 !important;
            padding: 7px 12px;
            font-weight: 800;
            font-size: 1.1rem;
            color: #0f0f15;
            border-bottom: 2px solid #cfd2dc;
        }
        tr.row-manually-hidden td:not(.col-hide):not(.col-sl) { opacity: .4; }
        tr.row-manually-hidden .col-name { text-decoration: line-through; }

        tr.row-parent-hidden td:not(.col-hide):not(.col-sl) { opacity: .3; }
        tr.row-parent-hidden .col-name {
            text-decoration: line-through;
            color: #9ca3af;
        }

        .row-full .col-result-full { padding: 5px 10px; }
        .file-upload-inline { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .file-upload-inline .file-input {
            flex: 1 1 180px;
            min-width: 0;
            font-size: .88rem;
            border: 1px dashed #c5c8d4;
            padding: 5px 8px;
            border-radius: 6px;
            background: #fafbff;
            color: #0f0f15;
        }
        .img-preview { display: flex; align-items: center; gap: 6px; white-space: nowrap; }
        .img-preview img {
            width: 38px;
            height: 38px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid #d0d0dd;
        }
        .download-link {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: .84rem;
            color: #0f0f15;
            text-decoration: none;
            margin-left: 6px;
            padding: 3px 10px;
            border-radius: 40px;
            background: #e8e6ff;
            white-space: nowrap;
            font-weight: 500;
        }
        .download-link:hover { background: #d4d0ff; }

        .ref-toggle-btn {
            display: none;
            align-items: center;
            gap: 5px;
            padding: 4px 12px;
            font-size: .78rem;
            font-weight: 600;
            background: #eef0f7;
            border: 1px solid #cfd2dc;
            border-radius: 20px;
            cursor: pointer;
            color: #0f0f15;
            transition: .15s;
        }
        .ref-toggle-btn:hover { background: #e0e3f0; }
        .ref-toggle-btn i     { font-size: .72rem; }

        .signoff-panel {
            background: #fafbff;
            border: 1px solid #e0e3f0;
            border-radius: 10px;
            padding: 10px 14px;
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            align-items: flex-end;
            gap: 10px 16px;
        }
        .signoff-group {
            display: flex;
            flex-direction: column;
            gap: 3px;
            flex: 1 1 150px;
            min-width: 0;
        }
        .signoff-group label {
            font-size: .76rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .35px;
            color: #0f0f15;
        }
        .signoff-group select,
        .signoff-group input {
            width: 100%;
            min-width: 0;
            padding: 6px 9px;
            border: 1px solid #c5c8d4;
            border-radius: 6px;
            font-size: .94rem;
            color: #0f0f15;
        }
        .signoff-check {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: .94rem;
            font-weight: 600;
            color: #0f0f15;
            padding-bottom: 2px;
        }
        .signoff-check input {
            width: 17px;
            height: 17px;
            accent-color: #7367f0;
        }

        .rpt-header {
            padding: 8px 14px;
            background: #f8f9fc;
            border-bottom: 1px solid #e5e7eb;
            border-top: 3px solid #7367f0;
        }
        .rpt-info-col {
            display: flex;
            flex-direction: column;
            gap: 4px;
            padding: 2px 0;
            min-width: 0;
        }
        .rpt-line {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 5px 10px;
            min-width: 0;
            font-size: 1.05rem;
            color: #0f0f15;
            line-height: 1.35;
        }
        .rpt-text {
            font-size: 1.05rem;
            font-weight: 700;
            color: #0f0f15;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            letter-spacing: .2px;
        }
        .rpt-text b { color: #0f0f15; font-weight: 700; }
        .rpt-icon {
            color: #6b7280;
            font-size: .9rem;
            flex-shrink: 0;
        }
        .rpt-sep {
            color: #9ca3af;
            font-weight: 700;
            user-select: none;
            font-size: 1.05rem;
        }

        .rpt-toolbar {
            display: flex;
            flex-wrap: nowrap;
            align-items: center;
            gap: 8px;
            padding: 2px 0;
            min-width: 0;
            justify-content: flex-end;
        }
        .rpt-test-badge {
            flex: 1 1 auto;
            min-width: 0;
            padding: 5px 12px;
            background: #f8f9fc;
            border: 1px solid #d0d3df;
            border-radius: 20px;
            box-shadow: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all .15s;
        }
        .rpt-test-badge:hover {
            border-color: #7367f0;
            background: #eef2ff;
        }
        .rpt-test-name {
            display: block;
            font-weight: 900;
            color: #0f0f15;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .rpt-actions {
            display: inline-flex;
            gap: 3px;
            flex-shrink: 0;
        }
        .rpt-btn {
            width: 30px;
            height: 30px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: none;
            border-radius: 6px;
            font-size: .78rem;
            color: #fff;
            cursor: pointer;
            transition: all .15s;
            flex-shrink: 0;
        }
        .rpt-btn i { font-size: .78rem; }
        .rpt-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,.15);
            color: #fff;
            text-decoration: none;
        }
        .rpt-btn-primary { background: #7367f0; }
        .rpt-btn-success { background: #28c76f; }
        .rpt-btn-info    { background: #00cfe8; }
        .rpt-btn-success.active,
        .rpt-btn-success[aria-expanded="true"] {
            background: #1ea35a;
            box-shadow: inset 0 2px 4px rgba(0,0,0,.15);
        }

        .rpt-search {
            flex: 0 0 150px;
            min-width: 0;
        }
        .rpt-search .form-control {
            font-size: .8rem;
            padding: 4px 8px;
            height: 30px;
            border-radius: 6px;
        }

        .patient-details-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 8px 16px;
            padding: 12px 16px;
            background: #f8f9fc;
            border-bottom: 1px solid #e5e7eb;
        }
        .pd-item {
            display: flex;
            flex-direction: column;
            gap: 3px;
            min-width: 0;
        }
        .pd-label {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: .7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .4px;
            color: #6b7280;
        }
        .pd-label i {
            font-size: .68rem;
            color: #7367f0;
        }
        .pd-value {
            font-size: .92rem;
            font-weight: 600;
            color: #111827;
            line-height: 1.3;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .pd-muted {
            font-size: .78rem;
            font-weight: 500;
            color: #9ca3af;
            margin-left: 4px;
        }
        .pd-link {
            color: #7367f0;
            text-decoration: none;
            font-weight: 700;
        }
        .pd-link:hover {
            color: #5b4ddb;
            text-decoration: underline;
        }
        .pd-chip {
            display: inline-flex;
            align-items: center;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .3px;
            line-height: 1.4;
        }
        .pd-chip-gender {
            background: #eef2ff;
            color: #4c3fd9;
            border: 1px solid #c7d2fe;
        }
        .pd-chip-blood {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }

        .test-validation-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: .72rem;
            font-weight: 700;
            letter-spacing: .2px;
            line-height: 1.4;
            white-space: nowrap;
            margin-left: 6px;
        }
        .test-validation-badge.valid {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        .test-validation-badge.invalid {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        form.is-invalid .component-table {
            box-shadow: inset 0 0 0 2px rgba(220, 38, 38, .25);
            border-radius: 6px;
        }

        @media (max-width: 1200px) {
            .component-table                { font-size: 1.02rem; }
            .component-table th             { font-size: .82rem; padding: 5px 7px; }
            .component-table td             { padding: 3px 7px; font-size: 1.02rem; }
        }

        @media (max-width: 992px) {
            .component-table                { font-size: .98rem; min-width: 720px; }
            .component-table th             { font-size: .78rem; padding: 5px 6px; }
            .component-table td             { padding: 3px 6px; font-size: .98rem; }
            .rpt-info-col,
            .rpt-toolbar { flex: 1 1 100%; max-width: 100%; }
            .rpt-toolbar { justify-content: flex-start; margin-top: 6px; }
            .rpt-search  { flex: 1 1 auto; }
            .patient-details-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        }

        @media (max-width: 768px) {
            .ref-toggle-btn { display: inline-flex; }
            body:not(.show-ref-mobile) .component-table th.col-ref,
            body:not(.show-ref-mobile) .component-table td.col-ref { display: none !important; }
            .component-table { font-size: .92rem; min-width: 560px; }
            .component-table th { font-size: .72rem; padding: 5px 5px; }
            .component-table td { padding: 3px 5px; font-size: .92rem; }
            .status-input   { font-size: .72rem; padding: 3px 4px; }
            .color-select   { font-size: .62rem; padding: 2px 2px; }
            .color-swatch   { width: 14px; height: 14px; }
            .table-input, .table-textarea { font-size: .88rem; padding: 5px 7px; }
            .signoff-panel { flex-direction: column; gap: 8px; padding: 10px 12px; }
            .signoff-group { flex: 1 1 100%; }
            .rpt-header { padding: 8px 10px; }
            .rpt-line { font-size: .98rem; gap: 4px 8px; }
            .rpt-text { font-size: .98rem; white-space: normal; }
            .rpt-sep  { font-size: .98rem; }
            .rpt-icon { font-size: .84rem; }
            .rpt-toolbar { flex-wrap: wrap; gap: 6px; margin-top: 6px; }
            .rpt-test-badge { flex: 1 1 100%; order: 1; padding: 4px 8px; }
            .rpt-test-name  { font-size: .8rem; }
            .rpt-actions    { order: 2; flex: 1 1 auto; }
            .rpt-btn        { flex: 1 1 auto; width: auto; min-width: 32px; height: 30px; }
            .rpt-search     { order: 3; flex: 1 1 100%; max-width: 100%; }
            .patient-details-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px 12px; padding: 10px 12px; }
            .pd-value { font-size: .86rem; }
        }

        @media (max-width: 480px) {
            .component-table { min-width: 500px; }
            .component-table th,
            .component-table td { padding: 2px 4px; font-size: .86rem; }
            .color-select { font-size: .58rem; padding: 1px 1px; }
            .color-swatch { width: 12px; height: 12px; }
            .hide-check { width: 16px; height: 16px; }
            .rpt-text { font-size: .92rem; }
            .rpt-sep  { font-size: .92rem; }
            .rpt-icon { font-size: .8rem; }
            .rpt-btn  { min-width: 28px; height: 28px; font-size: .7rem; }
            .rpt-btn i { font-size: .7rem; }
            .patient-details-grid { grid-template-columns: 1fr; gap: 6px 10px; padding: 10px 12px; }
            .pd-item { flex-direction: row; align-items: center; gap: 8px; }
            .pd-label { min-width: 90px; font-size: .68rem; }
            .pd-value { font-size: .84rem; }
        }
    </style>
@endsection

@section('content')

    @php
        $testConfig    = $report?->test?->config;
        $showStatusCol = (bool) ($testConfig?->show_status ?? false);
        $showMicCol    = (bool) ($testConfig?->culture_show_mic ?? false);
        $showZoneCol   = (bool) ($testConfig?->culture_show_zone ?? false);
        $showColorCol  = (bool) ($testConfig?->result_color ?? false);
        $tailColspan   = 3 + ($showStatusCol ? 1 : 0) + ($showColorCol ? 1 : 0);
        $totalCols     = 6 + ($showStatusCol ? 1 : 0) + ($showColorCol ? 1 : 0);
        $tableClass    = 'component-table'
                       . ($showStatusCol ? '' : ' no-status')
                       . ($showColorCol ? '' : ' no-color');
        $customJsKey   = $report?->test?->config?->custom_js;

        /* ── map of component_id → report row (for per-component frozen values) ── */
        $reportsByComponent = collect($report?->reports ?? [])->keyBy('component_id');
    @endphp

    <section class="invoice-add-wrapper">
        <div class="row invoice-add">
            <div class="col-12">
                <div class="card invoice-preview-card">

                    <div class="card-header rpt-header">
                        <div class="row col-12 m-0">

                            <div class="col-12 col-lg-7 rpt-info-col">
                                <div class="rpt-line">
                                    <span class="rpt-text" id="patient-info">
                                        <i class="fas fa-user rpt-icon"></i>
                                        @if (isset($data?->patient))
                                            {{ $data->patient->name }}
                                        @else
                                            No Patient
                                        @endif
                                    </span>

                                    @if (! empty($data?->patient?->age_format))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-birthday-cake rpt-icon"></i>
                                            {{ $data->patient->age_format }}
                                        </span>
                                    @endif

                                    @if (! empty($data?->patient?->gender))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-venus-mars rpt-icon"></i>
                                            {{ $data->patient->gender }}
                                        </span>
                                    @endif

                                    @if (! empty($data?->barcode))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-barcode rpt-icon"></i>
                                            {{ $data->barcode }}
                                        </span>
                                    @endif
                                </div>

                                @if (! empty($data?->referral?->name))
                                    <div class="rpt-line">
                                        <span class="rpt-text">
                                            <i class="fas fa-user-md rpt-icon"></i>
                                            Ref: {{ $data->referral->name }}
                                        </span>
                                        @if (! empty($data->referral->designation))
                                            <span class="rpt-sep">·</span>
                                            <span class="rpt-text">{{ $data->referral->designation }}</span>
                                        @endif
                                        @if (! empty($data->referral->phone))
                                            <span class="rpt-sep">·</span>
                                            <span class="rpt-text">
                                                <i class="fas fa-phone-alt rpt-icon"></i>
                                                {{ $data->referral->phone }}
                                            </span>
                                        @endif
                                    </div>
                                @endif
                            </div>

                            <div class="col-12 col-lg-5 rpt-toolbar">
                                <div class="rpt-search">
                                    <label class="has-float-label mb-0">
                                        <input type="search"
                                               class="form-control form-control-sm search-receipt"
                                               id="find"
                                               data-redirect="lab/report/edit/"
                                               autocomplete="off"
                                               title="Lab Receipt No">
                                        <span>Receipt No</span>
                                    </label>
                                </div>

                                <div class="rpt-test-badge">
                                    <span class="rpt-test-name">{{ $report?->test?->name }}</span>
                                    <span class="test-validation-badge" style="display:none;margin-left:6px;"></span>
                                    @if(isset($report?->test?->id))
                                        <span><a href="{{route('lab.test.edit',$report?->test?->id)}}"><i class="fas fa-edit"></i></a></span>
                                    @endif
                                    <input type="hidden" id="lab_id" value="{{ $data?->id }}">
                                </div>

                                <div class="rpt-actions">
                                    <a id="headingPatientDetail"
                                       class="rpt-btn rpt-btn-success"
                                       data-toggle="collapse" role="button"
                                       data-target="#viewPatientDetail"
                                       aria-expanded="false" aria-controls="viewPatientDetail"
                                       title="Patient Details">
                                        <i class="fas fa-user"></i>
                                    </a>

                                    <a id="headingTestDetail"
                                       class="rpt-btn rpt-btn-primary"
                                       data-toggle="collapse" role="button"
                                       data-target="#viewTestDetail"
                                       aria-expanded="true" aria-controls="viewTestDetail"
                                       title="Toggle Test Details">
                                        <i class="fas fa-vials"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-info"
                                       title="Previous"
                                       href="{{ route('lab.report.shift', ['id' => $data?->id, 'd' => 'previous', 'r' => 'edit']) }}">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-info"
                                       title="Next"
                                       href="{{ route('lab.report.shift', ['id' => $data?->id, 'd' => 'next', 'r' => 'edit']) }}">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-primary"
                                       title="Bulk Edit"
                                       href="{{ route('lab.report.bulk.edit.receipt', $data->id) }}">
                                        <i class="fas fa-layer-group"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-success"
                                       title="Combo Edit"
                                       href="{{ route('lab.report.combo.edit', $data->id) }}">
                                        <i class="fas fa-th-large"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- PATIENT DETAILS --}}
                    <div class="card-content collapse" id="viewPatientDetail" role="tabpanel">
                        <div class="card-body py-0">
                            <div class="patient-details-grid">
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-user"></i> Name</span>
                                    <span class="pd-value">{{ $data?->patient?->name ?: '—' }}</span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-phone-alt"></i> Phone</span>
                                    <span class="pd-value">
                                        @if($data?->patient?->phone)
                                            <a href="tel:{{ $data->patient->phone }}" class="pd-link">{{ $data->patient->phone }}</a>
                                        @else — @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-id-card"></i> NID</span>
                                    <span class="pd-value">{{ $data?->patient?->nid_bc ?: '—' }}</span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-birthday-cake"></i> Age</span>
                                    <span class="pd-value">
                                        {{ $data?->patient?->age_format ?: '—' }}
                                        @if($data?->patient?->dob)
                                            <small class="pd-muted">({{ $data->patient->dob }})</small>
                                        @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-venus-mars"></i> Gender</span>
                                    <span class="pd-value">
                                        @if($data?->patient?->gender)
                                            <span class="pd-chip pd-chip-gender">{{ $data->patient->gender }}</span>
                                        @else — @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-tint"></i> Blood</span>
                                    <span class="pd-value">
                                        @if($data?->patient?->blood_group)
                                            <span class="pd-chip pd-chip-blood">{{ $data->patient->blood_group }}</span>
                                        @else — @endif
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- TEST SELECTOR --}}
                    <div class="card-content collapse show" id="viewTestDetail" role="tabpanel">
                        <div class="card-body my-0 py-0">
                            @if(count($data?->labTest))
                                <ul class="list-inline my-0">
                                    @foreach($data?->labTest as $test)
                                        @if(!isset($test?->test))
                                            @continue
                                        @endif
                                        <li class="list-inline-item mx-0 my-h inline-block">
                                            <div class="input-group m-h">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text px-h">
                                                        <input class="check" type="checkbox"
                                                               data-test_id="{{$test?->id}}"
                                                               @if($test?->id == $report?->id) checked @endif>
                                                    </div>
                                                    @if(@$test?->done)
                                                        <div class="input-group-text px-h">
                                                            <a title="Print"
                                                               href="{{ route('lab.report.print', ['rid' => $test?->lab_id, 'tid' => $test?->id]) }}">
                                                                <i class="fas fa-print"></i>
                                                            </a>
                                                        </div>
                                                    @endif
                                                    <div class="input-group-text px-h">
                                                        <a title="Blank Print"
                                                           href="{{ route('lab.report.blank.print', ['rid' => $test?->lab_id, 'tid' => $test?->id]) }}">
                                                            <i class="fas fa-file-word"></i>
                                                        </a>
                                                    </div>
                                                    <span class="input-group-text pr-0"></span>
                                                </div>
                                                <div class="input-group-append">
                                                    <div class="input-group-text pl-0 pr-h">
                                                        <a class="{{ $test?->done ? 'text-primary' : ($test?->has_entered ? 'text-success' : 'text-dark') }}"
                                                           href="{{ route('lab.report.edit', ['rid' => $test?->lab_id, 'tid' => $test?->id]) }}">
                                                            {{ $test?->test?->name }}
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                    <li class="list-inline-item mx-0 my-h inline-block">
                                        <div class="input-group m-h">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text px-h">
                                                    <input id="check-all" type="checkbox" name="check-all" value="1">
                                                </div>
                                                <span class="input-group-text pr-0"></span>
                                            </div>
                                            <div class="input-group-append">
                                                <div class="input-group-text pl-0 pr-h">
                                                    <a id="all-print" class="text-dark" href="#" title="Print">
                                                        <i class="fas fa-print"></i>
                                                    </a>
                                                </div>
                                                <div class="input-group-text px-h">
                                                    <a id="all-preview" class="text-dark" href="#" title="Preview">
                                                        <i class="fas fa-file-pdf"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-inline-item mx-0 my-h inline-block">
                                        <button type="button" class="hide-all-btn" onclick="toggleAllHide(this)">
                                            <i class="fas fa-eye-slash"></i>
                                            <span>Hide All</span>
                                        </button>
                                    </li>
                                </ul>
                            @endif
                        </div>
                    </div>

                    {{-- FORM --}}
                    <div class="card-content">
                        <form id="edit_modal_form" method="post" enctype="multipart/form-data" autocomplete="off"
                              @if($customJsKey) data-custom-js="{{ $customJsKey }}" @endif>
                            @csrf
                            <div class="card-body mt-0 pt-0">
                                @if(isset($report))
                                    <div class="card card-primary">
                                        <div class="card-body p-0">
                                            <div style="text-align:right; padding:6px 10px 2px;">
                                                <button type="button" class="ref-toggle-btn"
                                                        onclick="toggleRefColumn(this)">
                                                    <i class="fas fa-columns"></i>
                                                    <span>Show Reference</span>
                                                </button>
                                            </div>

                                            <input type="hidden" id="model_id" name="model_id" value="{{ $report?->id }}">

                                            <div class="component-wrap">
                                                <table class="{{ $tableClass }}">
                                                    <thead>
                                                    <tr>
                                                        <th class="col-sl">SL</th>
                                                        <th class="col-hide"><i class="fas fa-eye-slash"></i></th>
                                                        <th class="col-name">Test Component</th>
                                                        <th class="col-result">Result</th>
                                                        <th class="col-unit">Unit</th>
                                                        <th class="col-ref">Reference</th>
                                                        @if($showStatusCol)<th class="col-status">Status</th>@endif
                                                        @if($showColorCol)<th class="col-color">Color</th>@endif
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    @php $currentTitleId = null; @endphp

                                                    @foreach($report?->components as $component)
                                                        <input type="hidden" name="component[{{$component?->id}}][id]" value="">
                                                        <input type="hidden" name="component[{{$component?->id}}][component_id]" value="{{$component?->id}}">
                                                        <input type="hidden" name="component[{{$component?->id}}][order]" value="{{$component?->order ?? 0}}">
                                                        <input type="hidden" name="component[{{$component?->id}}][type]" value="{{$component?->type}}">
                                                        <input type="hidden" name="component[{{$component?->id}}][unit]" value="{{$component?->unit ?? ''}}">

                                                        @if($component?->type == 'title')
                                                            @php $currentTitleId = 'title-' . $component?->id; @endphp
                                                            <tr class="row-title"
                                                                data-title-id="{{ $currentTitleId }}"
                                                                data-component-id="{{ $component?->id }}">
                                                                <td class="col-sl"></td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check hide-check-title"
                                                                           type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif
                                                                           value="1"
                                                                           onchange="handleTitleHideChange(this)">
                                                                </td>
                                                                <td colspan="{{ $totalCols - 2 }}">
                                                                    <b>{{ $component?->name }}</b>
                                                                </td>
                                                            </tr>

                                                        @elseif($component?->type == 'number')
                                                            <tr class="component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component['hidden'] ?? false) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result">
                                                                    <input type="text" class="table-input changeStatus"
                                                                           name="component[{{$component?->id}}][result]"
                                                                           value="{{$component?->result ?? ''}}"
                                                                           autocomplete="off">
                                                                </td>
                                                                <td class="col-unit">
                                                                    <input type="text" class="table-input"
                                                                           name="component[{{$component?->id}}][unit]"
                                                                           value="{{$component?->unit ?? ''}}"
                                                                           placeholder="Unit">
                                                                </td>
                                                                <td class="col-ref">
                                                                    @if(!empty($component?->available_references))
                                                                        <div class="ref-picker" data-ref-picker>
                                                                            <input type="hidden"
                                                                                   class="ref-hidden"
                                                                                   name="component[{{$component?->id}}][reference_text]"
                                                                                   value="{{ $component->reference_text ?? '' }}">

                                                                            <span class="ref-text ref-display"
                                                                                  title="Click to change reference"
                                                                                  onclick="openRefSelect(this)">
                                                                                {{ $component->reference_text ?: '—' }}
                                                                            </span>

                                                                            <select class="ref-select ref-editor"
                                                                                    style="display:none;"
                                                                                    onchange="applyRefSelect(this)"
                                                                                    onblur="closeRefSelect(this)">
                                                                                <option value="">—</option>
                                                                                @foreach($component->available_references as $ref)
                                                                                    <option value="{{ $ref }}"
                                                                                        @selected($component->reference_text === $ref)>
                                                                                        {{ $ref }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    @elseif($component?->reference_text)
                                                                        <input type="hidden"
                                                                               name="component[{{$component?->id}}][reference_text]"
                                                                               value="{{ $component->reference_text }}">
                                                                        <span class="ref-text">{{ $component->reference_text }}</span>
                                                                    @endif
                                                                </td>
                                                                @if($showStatusCol)
                                                                    <td class="col-status">
                                                                        <input type="text" class="status-input"
                                                                               name="component[{{$component?->id}}][status]"
                                                                               value="{{$component?->status ?? ''}}"
                                                                               list="status-list" placeholder="—">
                                                                    </td>
                                                                @endif
                                                                @if($showColorCol)
                                                                    <td class="col-color">
                                                                        <div class="color-cell-wrap">
                                                                            <span class="color-swatch {{ $component?->color ? '' : 'empty' }}"
                                                                                  style="{{ $component?->color ? 'background:#'.$component->color : '' }}"></span>
                                                                            <select class="color-select"
                                                                                    name="component[{{$component?->id}}][color]"
                                                                                    onchange="updateColorPreview(this)">
                                                                                <option value="" {{ !$component?->color ? 'selected' : '' }}>—</option>
                                                                                <option value="28c76f" {{ $component?->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                <option value="ea5455" {{ $component?->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                <option value="ff9f43" {{ $component?->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                <option value="ffd93d" {{ $component?->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                <option value="00cfe8" {{ $component?->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                <option value="7367f0" {{ $component?->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                <option value="ff6b9d" {{ $component?->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                <option value="a0a3b1" {{ $component?->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                            </select>
                                                                        </div>
                                                                    </td>
                                                                @endif
                                                            </tr>

                                                        @elseif($component?->type == 'select' || $component?->type == 'pattern')
                                                            <tr class="component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result" colspan="2">
                                                                    <input type="search"
                                                                           class="table-input dynamic-input"
                                                                           name="component[{{$component?->id}}][result]"
                                                                           value="{{$component?->result ?? ''}}"
                                                                           autocomplete="off"
                                                                           data-dynamic="{{ $component?->type == 'pattern' ? 'test_id,type' : 'id' }}"
                                                                           @if($component?->type == 'pattern') data-type="pattern" @else data-id="{{$component?->id}}" @endif
                                                                           multiple data-multiple="true"
                                                                           data-key="option_value"
                                                                           data-value="option_value"
                                                                           data-table="test_components"
                                                                           data-url="ajax/get-option-separate">
                                                                </td>
                                                                <td class="col-ref">
                                                                    @if(!empty($component?->available_references))
                                                                        <div class="ref-picker" data-ref-picker>
                                                                            <input type="hidden"
                                                                                   class="ref-hidden"
                                                                                   name="component[{{$component?->id}}][reference_text]"
                                                                                   value="{{ $component->reference_text ?? '' }}">

                                                                            <span class="ref-text ref-display"
                                                                                  title="Click to change reference"
                                                                                  onclick="openRefSelect(this)">
                                                                                {{ $component->reference_text ?: '—' }}
                                                                            </span>

                                                                            <select class="ref-select ref-editor"
                                                                                    style="display:none;"
                                                                                    onchange="applyRefSelect(this)"
                                                                                    onblur="closeRefSelect(this)">
                                                                                <option value="">—</option>
                                                                                @foreach($component->available_references as $ref)
                                                                                    <option value="{{ $ref }}"
                                                                                        @selected($component->reference_text === $ref)>
                                                                                        {{ $ref }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    @elseif($component?->reference_text)
                                                                        <input type="hidden"
                                                                               name="component[{{$component?->id}}][reference_text]"
                                                                               value="{{ $component->reference_text }}">
                                                                        <span class="ref-text">{{ $component->reference_text }}</span>
                                                                    @endif
                                                                </td>
                                                                @if($showStatusCol)
                                                                    <td class="col-status">
                                                                        <input type="text" class="status-input"
                                                                               name="component[{{$component?->id}}][status]"
                                                                               value="{{$component?->status ?? ''}}"
                                                                               list="status-list" placeholder="—">
                                                                    </td>
                                                                @endif
                                                                @if($showColorCol)
                                                                    <td class="col-color">
                                                                        <div class="color-cell-wrap">
                                                                            <span class="color-swatch {{ $component?->color ? '' : 'empty' }}"
                                                                                  style="{{ $component?->color ? 'background:#'.$component->color : '' }}"></span>
                                                                            <select class="color-select"
                                                                                    name="component[{{$component?->id}}][color]"
                                                                                    onchange="updateColorPreview(this)">
                                                                                <option value="" {{ !$component?->color ? 'selected' : '' }}>—</option>
                                                                                <option value="28c76f" {{ $component?->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                <option value="ea5455" {{ $component?->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                <option value="ff9f43" {{ $component?->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                <option value="ffd93d" {{ $component?->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                <option value="00cfe8" {{ $component?->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                <option value="7367f0" {{ $component?->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                <option value="ff6b9d" {{ $component?->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                <option value="a0a3b1" {{ $component?->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                            </select>
                                                                        </div>
                                                                    </td>
                                                                @endif
                                                            </tr>

                                                        @elseif($component?->type == 'text')
                                                            <tr class="component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result" colspan="2">
                                                                    <input type="search"
                                                                           class="table-input dynamic-input"
                                                                           name="component[{{$component?->id}}][result]"
                                                                           value="{{$component?->result ?? ''}}"
                                                                           autocomplete="off"
                                                                           data-dynamic="test_id,component_id"
                                                                           data-test_id="{{$component?->test_id ?? ''}}"
                                                                           data-component_id="{{$component?->id ?? ''}}"
                                                                           data-key="result" data-value="result"
                                                                           data-table="test_reports"
                                                                           data-url="ajax/get-dynamic-option">
                                                                </td>
                                                                <td class="col-ref">
                                                                    @if(!empty($component?->available_references))
                                                                        <div class="ref-picker" data-ref-picker>
                                                                            <input type="hidden"
                                                                                   class="ref-hidden"
                                                                                   name="component[{{$component?->id}}][reference_text]"
                                                                                   value="{{ $component->reference_text ?? '' }}">

                                                                            <span class="ref-text ref-display"
                                                                                  title="Click to change reference"
                                                                                  onclick="openRefSelect(this)">
                                                                                {{ $component->reference_text ?: '—' }}
                                                                            </span>

                                                                            <select class="ref-select ref-editor"
                                                                                    style="display:none;"
                                                                                    onchange="applyRefSelect(this)"
                                                                                    onblur="closeRefSelect(this)">
                                                                                <option value="">—</option>
                                                                                @foreach($component->available_references as $ref)
                                                                                    <option value="{{ $ref }}"
                                                                                        @selected($component->reference_text === $ref)>
                                                                                        {{ $ref }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    @elseif($component?->reference_text)
                                                                        <input type="hidden"
                                                                               name="component[{{$component?->id}}][reference_text]"
                                                                               value="{{ $component->reference_text }}">
                                                                        <span class="ref-text">{{ $component->reference_text }}</span>
                                                                    @endif
                                                                </td>
                                                                @if($showStatusCol)
                                                                    <td class="col-status">
                                                                        <input type="text" class="status-input"
                                                                               name="component[{{$component?->id}}][status]"
                                                                               value="{{$component?->status ?? ''}}"
                                                                               list="status-list" placeholder="—">
                                                                    </td>
                                                                @endif
                                                                @if($showColorCol)
                                                                    <td class="col-color">
                                                                        <div class="color-cell-wrap">
                                                                            <span class="color-swatch {{ $component?->color ? '' : 'empty' }}"
                                                                                  style="{{ $component?->color ? 'background:#'.$component->color : '' }}"></span>
                                                                            <select class="color-select"
                                                                                    name="component[{{$component?->id}}][color]"
                                                                                    onchange="updateColorPreview(this)">
                                                                                <option value="" {{ !$component?->color ? 'selected' : '' }}>—</option>
                                                                                <option value="28c76f" {{ $component?->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                <option value="ea5455" {{ $component?->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                <option value="ff9f43" {{ $component?->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                <option value="ffd93d" {{ $component?->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                <option value="00cfe8" {{ $component?->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                <option value="7367f0" {{ $component?->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                <option value="ff6b9d" {{ $component?->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                <option value="a0a3b1" {{ $component?->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                            </select>
                                                                        </div>
                                                                    </td>
                                                                @endif
                                                            </tr>

                                                        @elseif($component?->type == 'culture')
                                                            @php
                                                                /* Compare resolved value vs report-frozen value to
                                                                   decide italic "is-default" styling.
                                                                   $reportRow = frozen saved value; $component = resolved */
                                                                $reportRow = $reportsByComponent->get($component?->id);

                                                                $micIsDefault  = ! empty($component?->mic_value)
                                                                                 && empty($reportRow?->mic_value);
                                                                $zoneIsDefault = ! empty($component?->zone_value)
                                                                                 && empty($reportRow?->zone_value);
                                                            @endphp
                                                            <tr class="component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result" colspan="2">
                                                                    <div class="culture-input-group">
                                                                        @if($showMicCol)
                                                                            <input type="text"
                                                                                   class="table-input culture-mic {{ $micIsDefault ? 'is-default' : '' }}"
                                                                                   name="component[{{$component?->id}}][mic_value]"
                                                                                   value="{{ old('component.'.$component?->id.'.mic_value', $component?->mic_value ?? '') }}"
                                                                                   placeholder="MIC"
                                                                                   autocomplete="off">
                                                                        @endif

                                                                        @if($showZoneCol)
                                                                            <input type="text"
                                                                                   class="table-input culture-zone {{ $zoneIsDefault ? 'is-default' : '' }}"
                                                                                   name="component[{{$component?->id}}][zone_value]"
                                                                                   value="{{ old('component.'.$component?->id.'.zone_value', $component?->zone_value ?? '') }}"
                                                                                   placeholder="Zone"
                                                                                   autocomplete="off">
                                                                        @endif

                                                                        <select class="culture-interp interp-{{ strtolower($component?->result ?? 'nt') }}"
                                                                                name="component[{{$component?->id}}][result]"
                                                                                onchange="styleInterpSelect(this)">
                                                                            <option value=""   {{ !$component?->result       ? 'selected' : '' }}>—</option>
                                                                            <option value="S"  {{ $component?->result === 'S' ? 'selected' : '' }}>S</option>
                                                                            <option value="I"  {{ $component?->result === 'I' ? 'selected' : '' }}>I</option>
                                                                            <option value="R"  {{ $component?->result === 'R' ? 'selected' : '' }}>R</option>
                                                                            <option value="NT" {{ $component?->result === 'NT'? 'selected' : '' }}>NT</option>
                                                                        </select>
                                                                    </div>
                                                                </td>
                                                                <td class="col-ref">
                                                                    @if(!empty($component?->available_references))
                                                                        <div class="ref-picker" data-ref-picker>
                                                                            <input type="hidden"
                                                                                   class="ref-hidden"
                                                                                   name="component[{{$component?->id}}][reference_text]"
                                                                                   value="{{ $component->reference_text ?? '' }}">

                                                                            <span class="ref-text ref-display"
                                                                                  title="Click to change reference"
                                                                                  onclick="openRefSelect(this)">
                                                                                {{ $component->reference_text ?: '—' }}
                                                                            </span>

                                                                            <select class="ref-select ref-editor"
                                                                                    style="display:none;"
                                                                                    onchange="applyRefSelect(this)"
                                                                                    onblur="closeRefSelect(this)">
                                                                                <option value="">—</option>
                                                                                @foreach($component->available_references as $ref)
                                                                                    <option value="{{ $ref }}"
                                                                                        @selected($component->reference_text === $ref)>
                                                                                        {{ $ref }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    @elseif($component?->reference_text)
                                                                        <input type="hidden"
                                                                               name="component[{{$component?->id}}][reference_text]"
                                                                               value="{{ $component->reference_text }}">
                                                                        <span class="ref-text">{{ $component->reference_text }}</span>
                                                                    @endif
                                                                </td>
                                                                @if($showStatusCol)
                                                                    <td class="col-status">
                                                                        <input type="text" class="status-input"
                                                                               name="component[{{$component?->id}}][status]"
                                                                               value="{{$component?->status ?? ''}}"
                                                                               list="status-list" placeholder="—">
                                                                    </td>
                                                                @endif
                                                                @if($showColorCol)
                                                                    <td class="col-color">
                                                                        <div class="color-cell-wrap">
                                                                            <span class="color-swatch {{ $component?->color ? '' : 'empty' }}"
                                                                                  style="{{ $component?->color ? 'background:#'.$component->color : '' }}"></span>
                                                                            <select class="color-select"
                                                                                    name="component[{{$component?->id}}][color]"
                                                                                    onchange="updateColorPreview(this)">
                                                                                <option value="" {{ !$component?->color ? 'selected' : '' }}>—</option>
                                                                                <option value="28c76f" {{ $component?->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                <option value="ea5455" {{ $component?->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                <option value="ff9f43" {{ $component?->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                <option value="ffd93d" {{ $component?->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                <option value="00cfe8" {{ $component?->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                <option value="7367f0" {{ $component?->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                <option value="ff6b9d" {{ $component?->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                <option value="a0a3b1" {{ $component?->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                            </select>
                                                                        </div>
                                                                    </td>
                                                                @endif
                                                            </tr>

                                                        @elseif($component?->type == 'textarea')
                                                            <tr class="row-full component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result-full" colspan="{{ $tailColspan }}">
                                                                    <textarea id="component_{{$component?->id}}"
                                                                              class="table-textarea {{$component?->class ?? 'simple-editor'}}"
                                                                              rows="2"
                                                                              name="component[{{$component?->id}}][result_text]">{{$component?->result_text ?? $component?->result ?? ''}}</textarea>
                                                                </td>
                                                            </tr>

                                                        @elseif($component?->type == 'file')
                                                            <tr class="row-full component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result-full" colspan="{{ $tailColspan }}">
                                                                    <div class="file-upload-inline">
                                                                        <input type="file" class="file-input"
                                                                               id="{{$loop->iteration}}_image_"
                                                                               name="component[{{$component?->id}}][result_file]"
                                                                               @if($component?->default_value=='image') accept="image/*"
                                                                               @elseif($component?->default_value=='pdf') accept="application/pdf"
                                                                               @endif
                                                                               onchange="showPreview(event, '{{$loop->iteration}}_image');">
                                                                        @if($component?->document)
                                                                            <a href="{{$component->document}}" class="download-link" target="_blank">
                                                                                <i class="fas fa-download"></i> Download
                                                                            </a>
                                                                        @endif
                                                                        @if($component?->default_value=='image')
                                                                            <div class="img-preview">
                                                                                <img id="{{$loop->iteration}}_image_prev"
                                                                                     src="{{$component->document ?? '#'}}"
                                                                                     alt="preview">
                                                                            </div>
                                                                        @endif
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                        @else
                                                            <tr class="component-row"
                                                                data-component-id="{{$component?->id}}"
                                                                data-parent-title="{{ $currentTitleId }}">
                                                                <td class="col-sl">{{$loop->iteration}}</td>
                                                                <td class="col-hide">
                                                                    <input class="hide-check" type="checkbox"
                                                                           name="component[{{$component?->id}}][hide]"
                                                                           @if($component?->hide) checked @endif value="1"
                                                                           onchange="handleHideCheckboxChange(this)">
                                                                </td>
                                                                <td class="col-name">{{$component?->name}}</td>
                                                                <td class="col-result" colspan="2">
                                                                    <input type="text" class="table-input"
                                                                           name="component[{{$component?->id}}][result]"
                                                                           value="{{$component?->result ?? ''}}">
                                                                </td>
                                                                <td class="col-ref">
                                                                    @if(!empty($component?->available_references))
                                                                        <div class="ref-picker" data-ref-picker>
                                                                            <input type="hidden"
                                                                                   class="ref-hidden"
                                                                                   name="component[{{$component?->id}}][reference_text]"
                                                                                   value="{{ $component->reference_text ?? '' }}">

                                                                            <span class="ref-text ref-display"
                                                                                  title="Click to change reference"
                                                                                  onclick="openRefSelect(this)">
                                                                                {{ $component->reference_text ?: '—' }}
                                                                            </span>

                                                                            <select class="ref-select ref-editor"
                                                                                    style="display:none;"
                                                                                    onchange="applyRefSelect(this)"
                                                                                    onblur="closeRefSelect(this)">
                                                                                <option value="">—</option>
                                                                                @foreach($component->available_references as $ref)
                                                                                    <option value="{{ $ref }}"
                                                                                        @selected($component->reference_text === $ref)>
                                                                                        {{ $ref }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    @elseif($component?->reference_text)
                                                                        <input type="hidden"
                                                                               name="component[{{$component?->id}}][reference_text]"
                                                                               value="{{ $component->reference_text }}">
                                                                        <span class="ref-text">{{ $component->reference_text }}</span>
                                                                    @endif
                                                                </td>
                                                                @if($showStatusCol)
                                                                    <td class="col-status">
                                                                        <input type="text" class="status-input"
                                                                               name="component[{{$component?->id}}][status]"
                                                                               value="{{$component?->status ?? ''}}"
                                                                               list="status-list" placeholder="—">
                                                                    </td>
                                                                @endif
                                                                @if($showColorCol)
                                                                    <td class="col-color">
                                                                        <div class="color-cell-wrap">
                                                                            <span class="color-swatch {{ $component?->color ? '' : 'empty' }}"
                                                                                  style="{{ $component?->color ? 'background:#'.$component->color : '' }}"></span>
                                                                            <select class="color-select"
                                                                                    name="component[{{$component?->id}}][color]"
                                                                                    onchange="updateColorPreview(this)">
                                                                                <option value="" {{ !$component?->color ? 'selected' : '' }}>—</option>
                                                                                <option value="28c76f" {{ $component?->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                <option value="ea5455" {{ $component?->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                <option value="ff9f43" {{ $component?->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                <option value="ffd93d" {{ $component?->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                <option value="00cfe8" {{ $component?->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                <option value="7367f0" {{ $component?->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                <option value="ff6b9d" {{ $component?->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                <option value="a0a3b1" {{ $component?->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                            </select>
                                                                        </div>
                                                                    </td>
                                                                @endif
                                                            </tr>
                                                        @endif
                                                    @endforeach

                                                    {{-- COMMENT --}}
                                                    @if(isset($report->test_id))
                                                        <tr class="row-full comment-row" id="commentRow">
                                                            <td class="col-result-full" colspan="{{ $tailColspan + 3 }}">
                                                                <b>Comment</b>
                                                                <textarea id="comment"
                                                                          class="table-textarea simple-editor"
                                                                          rows="2"
                                                                          data-key="comment_test_{{ $report->test_id ?? '' }}"
                                                                          name="comment">{{$report?->comment ?? ''}}</textarea>
                                                            </td>
                                                        </tr>
                                                    @endif
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        {{-- SIGN-OFF --}}
                                        <div class="card-footer">
                                            <div class="signoff-panel">
                                                <div class="signoff-group">
                                                    <label>Prepared By *</label>
                                                    @php
                                                        $selectedPrepared     = $test['prepared']['name'] ?? Cache::get('prepared_tid' . $report->test_id . '_uid' . auth()->id());
                                                        $selectedPreparedId   = $test['prepared_by'] ?? ($selectedPrepared['id'] ?? null);
                                                        $selectedPreparedName = $test['prepared']['name'] ?? ($selectedPrepared['name'] ?? null);
                                                    @endphp
                                                    <select class="dynamic-select select2"
                                                            id="prepared_by" name="prepared_by"
                                                            data-placeholder="Prepared By" data-container="select-sm"
                                                            data-tenant="true" data-table="users"
                                                            data-value="id" data-column_names="name,phone,code"
                                                            data-multi_value="name,code" data-key="id"
                                                            data-url="ajax/get-dynamic-option">
                                                        @if(isset($selectedPreparedId) && isset($selectedPreparedName))
                                                            <option value="{{ $selectedPreparedId }}" selected>{{ $selectedPreparedName }}</option>
                                                        @endif
                                                    </select>
                                                    <span class="text-danger" id="error_prepared_by"></span>
                                                </div>

                                                <div class="signoff-group">
                                                    <label>Reviewed By</label>
                                                    @php
                                                        $selectedReviewer     = $test['reviewed']['name'] ?? Cache::get('reviewed_tid' . $report->test_id . '_uid' . auth()->id());
                                                        $selectedReviewerId   = $test['reviewed_by'] ?? ($selectedReviewer['id'] ?? null);
                                                        $selectedReviewerName = $test['reviewed']['name'] ?? ($selectedReviewer['name'] ?? null);
                                                    @endphp
                                                    <select class="dynamic-select select2"
                                                            id="reviewed_by" name="reviewed_by"
                                                            data-placeholder="Reviewed By" data-container="select-sm"
                                                            data-tenant="true" data-table="users"
                                                            data-value="id" data-column_names="name,phone,code"
                                                            data-multi_value="name,phone,code" data-key="id"
                                                            data-url="ajax/get-dynamic-option">
                                                        <option value="">Select Reviewed By</option>
                                                        @if(isset($selectedReviewerId) && isset($selectedReviewerName))
                                                            <option value="{{ $selectedReviewerId }}" selected>{{ $selectedReviewerName }}</option>
                                                        @endif
                                                    </select>
                                                    <span class="text-danger" id="error_reviewed_by"></span>
                                                </div>

                                                <div class="signoff-group">
                                                    <label>Authorized By</label>
                                                    @php
                                                        $selectedAuthorized     = $test['authorized']['name'] ?? Cache::get('authorized_tid' . $report->test_id . '_uid' . auth()->id());
                                                        $selectedAuthorizedId   = $test['authorized_by'] ?? ($selectedAuthorized['id'] ?? null);
                                                        $selectedAuthorizedName = $test['authorized']['name'] ?? ($selectedAuthorized['name'] ?? null);
                                                    @endphp
                                                    <select class="dynamic-select select2"
                                                            id="authorized_by" name="authorized_by"
                                                            data-placeholder="Authorized By" data-container="select-sm"
                                                            data-tenant="true" data-table="users"
                                                            data-value="id" data-column_names="name,phone,code"
                                                            data-multi_value="name,phone,code" data-key="id"
                                                            data-url="ajax/get-dynamic-option">
                                                        <option value="">Select Authorized By</option>
                                                        @if(isset($selectedAuthorizedId) && isset($selectedAuthorizedName))
                                                            <option value="{{ $selectedAuthorizedId }}" selected>{{ $selectedAuthorizedName }}</option>
                                                        @endif
                                                    </select>
                                                    <span class="text-danger" id="error_authorized_by"></span>
                                                </div>

                                                <div class="signoff-check">
                                                    <input class="dt-check" id="complete" type="checkbox"
                                                           name="complete" @if(optional($report)->done) checked @endif value="1">
                                                    <label for="complete" style="margin:0; text-transform:none;">
                                                        Report is Completed
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="form-group text-center mt-1">
                                                <button class="btn btn-primary mr-1 submit-btn" type="submit">Save</button>
                                                <button type="button" class="btn btn-outline-secondary"
                                                        onclick="window.location.reload();">Reload</button>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    <h6 class="text-center">{{__('No data available')}}</h6>
                                @endif
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <datalist id="status-list">
        <option value="Normal">
        <option value="High">
        <option value="Low">
        <option value="Abnormal">
        <option value="Critical">
        <option value="Info">
        <option value="Pending">
    </datalist>

    @include('modal.modal-pdf')

@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset('js/tinymce/tinymce.min.js') }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/pages/lab-report.js')) }}"></script>
    <script src="{{ asset(mix('js/scripts/pages/test-custom-function.js')) }}"></script>
    <script src="{{ asset(mix('/vendors/js/bookmark-editor/bookmark-manager.js')) }}"></script>
    <script src="{{ asset(mix('js/scripts/pages/dynamic.min.js')) }}"></script>

    <script>
        function styleInterpSelect(sel) {
            sel.classList.remove('interp-s', 'interp-i', 'interp-r', 'interp-nt');
            const v = (sel.value || 'nt').toLowerCase();
            sel.classList.add('interp-' + (['s', 'i', 'r'].includes(v) ? v : 'nt'));
        }

        function openRefSelect(spanEl) {
            const wrap    = spanEl.closest('[data-ref-picker]');
            const select  = wrap.querySelector('.ref-editor');
            const display = wrap.querySelector('.ref-display');

            display.style.display = 'none';
            select.style.display  = '';
            select.focus();
        }

        function applyRefSelect(selectEl) {
            const wrap    = selectEl.closest('[data-ref-picker]');
            const display = wrap.querySelector('.ref-display');
            const hidden  = wrap.querySelector('.ref-hidden');

            const value = selectEl.value;
            const label = selectEl.options[selectEl.selectedIndex]?.text ?? value ?? '—';

            if (hidden)  hidden.value = value;
            if (display) display.innerHTML = label || '—';

            selectEl.style.display = 'none';
            display.style.display  = '';
        }

        function closeRefSelect(selectEl) {
            setTimeout(() => {
                if (selectEl.style.display === 'none') return;
                const wrap    = selectEl.closest('[data-ref-picker]');
                const display = wrap.querySelector('.ref-display');
                selectEl.style.display = 'none';
                display.style.display  = '';
            }, 150);
        }

        function handleTitleHideChange(checkbox) {
            const titleRow = checkbox.closest('.row-title');
            const titleId  = titleRow?.dataset?.titleId;

            if (!titleId) return;

            document.querySelectorAll('tr[data-parent-title="' + titleId + '"]').forEach(function (row) {
                const own = row.querySelector('.hide-check:not(.hide-check-title)');

                if (checkbox.checked) {
                    row.classList.add('row-parent-hidden');
                    if (own) own.checked = true;
                } else {
                    row.classList.remove('row-parent-hidden');
                    if (own) own.checked = false;
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.culture-interp').forEach(function (sel) {
                styleInterpSelect(sel);
            });

            document.querySelectorAll('.hide-check-title:checked').forEach(function (cb) {
                handleTitleHideChange(cb);
            });

            document.querySelectorAll('.culture-mic.is-default, .culture-zone.is-default').forEach(function (inp) {
                inp.addEventListener('input', function () {
                    this.classList.remove('is-default');
                }, { once: true });
            });
        });

        document.addEventListener('DOMContentLoaded', function () {
            var previewBtn = document.getElementById('all-preview');
            if (!previewBtn) return;

            previewBtn.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var labId = document.getElementById('lab_id')?.value;
                if (!labId) {
                    if (window.toastr) toastr.warning('Lab ID not found');
                    return;
                }

                var ids = [];
                document.querySelectorAll('.check:checked').forEach(function (cb) {
                    if (cb.dataset.test_id) ids.push(cb.dataset.test_id);
                });

                if (!ids.length) {
                    if (window.toastr) toastr.warning('Select at least one test.');
                    return;
                }

                var url = (window.assetPath || '/') + 'lab/report/print/' + labId + '/' + ids.join(',');

                if (!window.PdfPreview) {
                    window.open(url, '_blank');
                    return;
                }

                // ── Warm cache in background so first paint is fast ──
                if (!window.__pdfWarm) window.__pdfWarm = new Set();
                if (!window.__pdfWarm.has(url) && window.pdfjsLib) {
                    window.__pdfWarm.add(url);
                    window.pdfjsLib.getDocument({ url: url, withCredentials: true }).promise
                        .catch(function () {});
                }

                // ── Let PdfPreview own the entire modal lifecycle ──
                PdfPreview.open(url, {
                    title: ids.length > 1 ? ids.length + ' Tests' : 'Report Preview',
                    onPrint: function () {
                        if (typeof window.windowsPrint === 'function') {
                            window.windowsPrint(url);
                        } else {
                            window.open(url, '_blank');
                        }
                    }
                });
            });
        });
    </script>
@endsection
