<?php
// Paste next to the existing lab.report.* routes (same group / middleware / prefix),
// e.g. right after 'lab.report.bulk.update.receipt'.
// If your group is not already prefixed 'lab/report', adjust the URLs below.
// The header search box redirects to  lab/report/combo-edit/{id}  — keep that URL.

Route::get('report/combo-edit/{rid}', [LabReportController::class, 'comboEdit'])
    ->name('lab.report.combo.edit');

Route::post('report/combo-update', [LabReportController::class, 'comboUpdate'])
    ->name('lab.report.combo.update');

// Prev / Next on the combo page reuse your existing route:
//   route('lab.report.bulk.shift', ['id' => $id, 'd' => 'next', 'r' => 'combo'])
// (LabReportController::shiftTo now understands r = 'combo').
