@extends('layouts/contentLayoutHideNavbar')
@section('title', 'Bulk Edit Receipt - ' . ($receipt->sl_no ?? ''))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection

@section('page-style')
   <style>
       .invoice-add-wrapper,.invoice-add-wrapper .card,.invoice-add-wrapper .card-body,.invoice-add-wrapper label,.invoice-add-wrapper small{color:var(--rpt-body)}.rpt-info-col,.rpt-line{display:flex;min-width:0}.cat-filter-btn .cat-name,.pd-value,.rpt-test-name,.rpt-text{text-overflow:ellipsis;overflow:hidden}.component-table th,.pd-label{letter-spacing:.5px;text-transform:uppercase}.cat-filter-btn,.hide-all-btn,.pd-value,.rpt-test-name,.rpt-text{white-space:nowrap}.invoice-add-wrapper{--rpt-primary:#7367f0;--rpt-primary-dark:#5e50d9;--rpt-primary-soft:#eeedfc;--rpt-ink:#1e293b;--rpt-body:#334155;--rpt-muted:#64748b;--rpt-faint:#94a3b8;--rpt-border:#e2e8f0;--rpt-border-strong:#cbd5e1;--rpt-surface:#ffffff;--rpt-soft:#f8fafc;--rpt-soft-2:#f1f5f9;--rpt-green:#28c76f;--rpt-green-dark:#1f9b57;--rpt-orange:#ff9f43;--rpt-cyan:#00cfe8;--rpt-radius:10px;--rpt-shadow-sm:0 1px 3px rgba(30, 41, 59, .07);--rpt-shadow-md:0 4px 14px rgba(30, 41, 59, .10)}.invoice-add-wrapper b,.invoice-add-wrapper h1,.invoice-add-wrapper h2,.invoice-add-wrapper h3,.invoice-add-wrapper h4,.invoice-add-wrapper h5,.invoice-add-wrapper h6,.invoice-add-wrapper strong,.rpt-line,.rpt-text,.rpt-text b{color:var(--rpt-ink)}.invoice-add-wrapper .text-muted{color:var(--rpt-muted)!important}.category-content{transition:.3s}.toggle-icon,.toggle-icon-sm{transition:transform .3s}.toggle-icon.collapsed{transform:rotate(-90deg)}.test-card{border:1px solid var(--rpt-border)!important;border-radius:var(--rpt-radius)!important;box-shadow:var(--rpt-shadow-sm);overflow:hidden;background:var(--rpt-surface)}.test-card.completed{border-left:4px solid var(--rpt-green)!important}.test-card.pending{border-left:4px solid var(--rpt-orange)!important}.invoice-preview-card{border:1px solid var(--rpt-border)!important;border-radius:14px!important;box-shadow:var(--rpt-shadow-md);overflow:hidden}.cat-filter-btn,.category-container,.rpt-test-badge:hover{box-shadow:var(--rpt-shadow-sm)}.rpt-header{padding:14px 16px;background:linear-gradient(135deg,#fff 0,#f4f2fe 60%,#eeedfc 100%);border-bottom:1px solid var(--rpt-border);border-top:4px solid var(--rpt-primary)}.rpt-info-col{flex-direction:column;gap:6px;padding:2px 0}.rpt-line{flex-wrap:wrap;align-items:center;gap:5px 10px;font-size:1.02rem;line-height:1.4}.rpt-text{font-size:1.02rem;font-weight:700;display:inline-flex;align-items:center;gap:5px}.rpt-text b{font-weight:800}.rpt-icon{color:var(--rpt-primary);font-size:.9rem;flex-shrink:0}.rpt-sep{color:var(--rpt-faint);font-weight:700;user-select:none}.rpt-toolbar{display:flex;flex-wrap:nowrap;align-items:center;gap:8px;padding:2px 0;min-width:0;justify-content:flex-end}.rpt-test-badge{flex:1 1 auto;min-width:0;padding:6px 14px;background:var(--rpt-surface);border:1px solid var(--rpt-border-strong);border-left:4px solid var(--rpt-primary);border-radius:22px;display:inline-flex;align-items:center;gap:6px;transition:.15s}.rpt-test-badge:hover{border-color:var(--rpt-primary)}.rpt-test-name{display:block;font-weight:800;color:var(--rpt-ink)}.rpt-actions{display:inline-flex;gap:4px;flex-shrink:0}.pd-label,.rpt-btn{align-items:center}.rpt-btn{width:32px;height:32px;padding:0;display:inline-flex;justify-content:center;border:none;border-radius:8px;font-size:.8rem;color:#fff;cursor:pointer;transition:.15s;flex-shrink:0}.rpt-btn:hover{transform:translateY(-1px);box-shadow:0 4px 10px rgba(30,41,59,.22);color:#fff;text-decoration:none}.rpt-btn-primary{background:var(--rpt-primary)}.rpt-btn-success{background:var(--rpt-green)}.rpt-btn-info{background:var(--rpt-cyan)}.rpt-btn-success.active,.rpt-btn-success[aria-expanded=true]{background:var(--rpt-green-dark);box-shadow:inset 0 2px 4px rgba(0,0,0,.18)}.rpt-search{flex:0 0 170px;min-width:0}.rpt-search .form-control{font-size:.85rem;padding:5px 10px;height:34px;border-radius:8px;border-color:var(--rpt-border-strong);color:var(--rpt-ink);background:var(--rpt-surface)}.rpt-search .form-control:focus{border-color:var(--rpt-primary);box-shadow:0 0 0 3px rgba(115,103,240,.18)}.patient-details-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 18px;padding:14px 18px;background:var(--rpt-soft);border-bottom:1px solid var(--rpt-border)}.pd-item{display:flex;flex-direction:column;gap:3px;min-width:0;background:var(--rpt-surface);border:1px solid var(--rpt-border);border-radius:8px;padding:8px 10px}.pd-chip,.pd-label{display:inline-flex}.pd-label{gap:5px;font-size:.68rem;font-weight:800;color:var(--rpt-muted)}.pd-label i{font-size:.68rem;color:var(--rpt-primary)}.pd-value{font-size:.92rem;font-weight:700;color:var(--rpt-ink);line-height:1.3}.pd-muted{font-size:.76rem;font-weight:500;color:var(--rpt-faint);margin-left:4px}.pd-chip-gender,.pd-link{color:var(--rpt-primary-dark)}.pd-link{text-decoration:none;font-weight:700}.pd-link:hover{color:var(--rpt-primary);text-decoration:underline}.pd-chip{align-items:center;align-self:flex-start;padding:2px 10px;border-radius:12px;font-size:.76rem;font-weight:700;letter-spacing:.3px;line-height:1.5}.pd-chip-gender{background:var(--rpt-primary-soft);border:1px solid #d6d1fa}.pd-chip-blood{background:#fee2e2;color:#b91c1c;border:1px solid #fecaca}.invoice-add-wrapper .badge{font-weight:700;letter-spacing:.2px;padding:.35em .7em}.invoice-add-wrapper .badge-primary{background:var(--rpt-primary)!important;color:#fff!important}.invoice-add-wrapper .badge-success{background:var(--rpt-green)!important;color:#fff!important}.invoice-add-wrapper .badge-warning{background:var(--rpt-orange)!important;color:#4a2c00!important}.invoice-add-wrapper .badge-info{background:var(--rpt-cyan)!important;color:#063a44!important}.invoice-add-wrapper .badge-danger{background:#ea5455!important;color:#fff!important}.component-table th,.invoice-add-wrapper .badge-light,.row-title td{background:var(--rpt-soft-2)!important}.invoice-add-wrapper .badge-light{color:var(--rpt-ink)!important;border:1px solid var(--rpt-border-strong)}.top-actions .btn{border-radius:20px;font-weight:600}.top-actions .btn-success{background:var(--rpt-green);border-color:var(--rpt-green)}.top-actions .btn-success:hover{background:var(--rpt-green-dark);border-color:var(--rpt-green-dark)}.top-actions .btn-primary{background:var(--rpt-primary);border-color:var(--rpt-primary)}.top-actions .btn-primary:hover{background:var(--rpt-primary-dark);border-color:var(--rpt-primary-dark)}.top-actions .btn-secondary{background:var(--rpt-surface);color:var(--rpt-body);border:1px solid var(--rpt-border-strong)}.category-panel .btn-reset:hover,.top-actions .btn-secondary:hover{background:var(--rpt-soft-2);color:var(--rpt-ink)}.progress{background:var(--rpt-soft-2);border-radius:10px}.progress-bar{background:linear-gradient(90deg,var(--rpt-green),#48da89)!important;transition:width .6s cubic-bezier(.34, 1.2, .64, 1)}.progress-text{color:var(--rpt-muted)!important;font-weight:700!important;font-size:.8rem;margin-top:4px}.category-filter-bar{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:12px 14px;background:var(--rpt-soft);border-bottom:1px solid var(--rpt-border);position:sticky;top:0;z-index:20}.cat-filter-btn{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border:1.5px solid var(--rpt-border-strong);background:var(--rpt-surface);border-radius:24px;font-size:.84rem;font-weight:600;color:var(--rpt-body);cursor:pointer;transition:transform .2s cubic-bezier(.34,1.56,.64,1),background-color .2s,color .2s,border-color .2s,box-shadow .2s;line-height:1.35}.cat-filter-btn .cat-dot{width:8px;height:8px;border-radius:50%;background:var(--cat-a,var(--rpt-primary));box-shadow:0 0 0 3px rgba(115,103,240,.18);flex-shrink:0}.cat-filter-btn.cat-all i{font-size:.82rem;color:var(--rpt-primary)}.cat-filter-btn .cat-name{max-width:180px;color:inherit}.cat-filter-btn .cat-count{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:20px;padding:0 7px;border-radius:10px;background:var(--rpt-soft-2);color:var(--rpt-body);font-size:.72rem;font-weight:800;letter-spacing:.2px}.cat-filter-btn:hover{transform:translateY(-2px);border-color:var(--cat-a,var(--rpt-primary));color:var(--rpt-ink);box-shadow:0 6px 16px rgba(30,41,59,.14)}.cat-filter-btn.active{background:linear-gradient(135deg,var(--cat-a,#7367f0),var(--cat-b,#5e50d9));border-color:transparent;color:#fff;box-shadow:0 6px 18px rgba(94,80,217,.35)}.cat-filter-btn.active .cat-dot{background:#fff;box-shadow:0 0 0 4px rgba(255,255,255,.3)}.cat-filter-btn.active.cat-all i{color:#fff}.cat-filter-btn.active .cat-count{background:rgba(255,255,255,.25);color:#fff}.cat-filter-btn.is-done:not(.active){border-color:rgba(40,199,111,.5);background:#f0fbf4}.category-container{border:1px solid var(--rpt-border)!important;border-radius:12px!important;overflow:hidden;animation:.4s cubic-bezier(.34,1.2,.64,1) both catFadeIn}.category-container.is-hidden{display:none!important}@keyframes catFadeIn{from{opacity:0;transform:translateY(8px) scale(.99)}to{opacity:1;transform:translateY(0) scale(1)}}.category-header{background:linear-gradient(135deg,#f6f5fe 0,#eeedfc 100%)!important;border-bottom:1px solid var(--rpt-border);padding:10px 12px!important}.category-header h5,.test-header b{color:var(--rpt-ink)!important;font-weight:800!important}.category-header h5 i{color:var(--rpt-primary)!important;margin-right:4px}.badge-progress{background:var(--rpt-surface)!important;color:var(--rpt-primary-dark)!important;border:1px solid #d6d1fa}.category-actions .btn{border-radius:8px}.category-save-btn{background:var(--rpt-cyan);color:#063a44}.category-save-btn:hover{background:#00b8cf;color:#063a44}.category-complete-btn{background:var(--rpt-green);color:#fff}.category-complete-btn:hover{background:var(--rpt-green-dark);color:#fff}.category-panel .btn-apply,.category-print-btn{background:var(--rpt-primary);color:#fff}.category-print-btn:hover{background:var(--rpt-primary-dark);color:#fff}.test-header{background:var(--rpt-soft);border-bottom:1px solid var(--rpt-border);padding:8px 12px!important}.test-header .text-muted{color:var(--rpt-muted)!important;font-weight:500}.toggle-icon-sm{color:var(--rpt-primary)}.component-wrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}.component-table{width:100%;border-collapse:collapse;font-size:1rem;color:var(--rpt-body);table-layout:fixed;background:var(--rpt-surface)}.component-table th{font-weight:800;font-size:.74rem;padding:8px;text-align:left;color:var(--rpt-ink)!important;border-bottom:2px solid var(--rpt-border-strong);white-space:nowrap}.component-table td{padding:5px 8px;border-bottom:1px solid var(--rpt-border);vertical-align:middle;font-size:.98rem;line-height:1.35;color:var(--rpt-body);word-break:break-word}.component-table tbody tr:hover td{background:#f6f5fe}.component-table .col-sl{width:3%;text-align:center;font-weight:800;color:var(--rpt-ink)}.component-table .col-hide{width:5%;text-align:center}.component-table .col-name{width:20%;font-weight:700;color:var(--rpt-ink)!important}.component-table .col-result,.component-table.no-status.no-color .col-name,.component-table.no-status.no-color .col-ref{width:24%}.component-table .col-status,.component-table .col-unit,.component-table.no-color .col-status{width:10%}.component-table .col-ref{width:17%;font-size:.88rem;line-height:1.25}.component-table .col-color{width:11%;text-align:center}.component-table.no-color .col-name,.component-table.no-color .col-ref,.component-table.no-status .col-name{width:22%}.component-table.no-color .col-result,.component-table.no-status .col-result{width:26%}.component-table.no-color .col-unit,.component-table.no-status .col-color,.component-table.no-status .col-unit{width:12%}.component-table.no-status .col-ref{width:20%}.component-table.no-status.no-color .col-result{width:30%}.component-table.no-status.no-color .col-unit{width:14%}.table-input,.table-select,.table-textarea{width:100%;min-width:0;padding:6px 10px;border:1.5px solid var(--rpt-border-strong);border-radius:7px;font-size:.95rem;font-family:inherit;color:var(--rpt-ink)!important;font-weight:600;background:var(--rpt-surface);transition:.15s}.table-input::placeholder,.table-textarea::placeholder{color:var(--rpt-faint);font-weight:500}.table-input:hover,.table-select:hover,.table-textarea:hover{border-color:#b6b9f0}.table-input:focus,.table-select:focus,.table-textarea:focus{background:#fff;border-color:var(--rpt-primary);box-shadow:0 0 0 3px rgba(115,103,240,.18);outline:0}.ref-picker .ref-display,.ref-text{display:inline-block;max-width:100%;padding:3px 9px;border-radius:6px;background:var(--rpt-primary-soft);border-left:3px solid var(--rpt-primary);line-height:1.3;word-break:break-word;font-size:.85rem;font-weight:600}.table-textarea{resize:vertical;min-height:44px}.ref-text{color:var(--rpt-primary-dark)!important}.color-select,.row-title td,.status-input{color:var(--rpt-ink)!important}.ref-picker{display:flex;flex-direction:column;gap:4px}.ref-picker .ref-display{cursor:pointer;color:var(--rpt-primary-dark);transition:.15s}.ref-picker .ref-display:hover{background:#e2dffc}.ref-picker .ref-display:empty::before{content:'—';color:var(--rpt-faint)}.ref-picker .ref-editor{width:100%;padding:5px 8px;border:1.5px solid var(--rpt-primary);border-radius:7px;font-size:.85rem;font-weight:600;color:var(--rpt-ink);background:#fffbe6;outline:0;box-shadow:0 0 0 3px rgba(115,103,240,.18)}.culture-input-group{display:flex;gap:6px;align-items:stretch;min-width:0}.culture-input-group .culture-mic,.culture-input-group .culture-zone{flex:1 1 0;min-width:55px;text-align:center;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:600;transition:.15s}.culture-input-group .culture-mic.is-default,.culture-input-group .culture-zone.is-default{color:#6b7280;font-style:italic;background:#f9fafb}.culture-input-group .culture-mic.is-default:focus,.culture-input-group .culture-zone.is-default:focus{font-style:normal;color:var(--rpt-ink);background:#fffbe6}.culture-interp{flex:0 0 78px;min-width:78px;padding:5px 8px;border:1.5px solid var(--rpt-border-strong);border-radius:6px;font-size:1.05rem;font-weight:800;text-align:center;text-align-last:center;cursor:pointer;background:#fff}.color-select,.hide-all-btn,.status-input{font-weight:700;background:var(--rpt-surface)}.culture-interp:focus{outline:0;border-color:var(--rpt-primary);box-shadow:0 0 0 3px rgba(115,103,240,.18)}.culture-interp.interp-s{background:#d4edda;color:#0d6b3f;border-color:#a7f3d0}.culture-interp.interp-i{background:#fff3cd;color:#856404;border-color:#ffe69c}.culture-interp.interp-r{background:#f8d7da;color:#842029;border-color:#fecaca}.culture-interp.interp-nt{background:#e9ecef;color:#6c757d;border-color:#ced4da}.status-input{width:100%;min-width:0;padding:5px 6px;border:1.5px solid var(--rpt-border-strong);border-radius:6px;font-size:.8rem;text-align:center}.status-input::placeholder{color:var(--rpt-faint);font-weight:400}.color-select:focus,.signoff-group input:focus,.signoff-group select:focus,.status-input:focus{border-color:var(--rpt-primary);box-shadow:0 0 0 3px rgba(115,103,240,.18);outline:0}.color-cell-wrap{display:flex;align-items:center;gap:5px;justify-content:center}.color-swatch{width:18px;height:18px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 1px var(--rpt-border-strong),0 1px 3px rgba(0,0,0,.15);flex-shrink:0}.color-swatch.empty{background:0 0!important;box-shadow:0 0 0 1px var(--rpt-border-strong) inset;border:2px dashed var(--rpt-border-strong)}.color-select{flex:1;min-width:0;padding:4px;border:1.5px solid var(--rpt-border-strong);border-radius:6px;font-size:.7rem;cursor:pointer}.color-select:hover{border-color:var(--rpt-primary)}.hide-check{width:17px;height:17px;accent-color:var(--rpt-primary);cursor:pointer}.hide-all-btn{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;font-size:.8rem;border-radius:22px;border:1.5px solid var(--rpt-border-strong);color:var(--rpt-body);cursor:pointer;transition:.15s}.hide-all-btn.active,.hide-all-btn:hover{background:var(--rpt-primary-soft);border-color:var(--rpt-primary);color:var(--rpt-primary-dark)}tr.row-manually-hidden td:not(.col-hide):not(.col-sl){opacity:.45}tr.row-manually-hidden .col-name{text-decoration:line-through}tr.row-parent-hidden td:not(.col-hide):not(.col-sl){opacity:.3}tr.row-parent-hidden .col-name{text-decoration:line-through;color:#9ca3af}.row-title td{padding:7px 10px;font-weight:800;font-size:.95rem;border-bottom:1.5px solid var(--rpt-border-strong);letter-spacing:.3px}.row-full .col-result-full{padding:5px 9px}.file-upload-inline{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.file-upload-inline .file-input{flex:1 1 180px;min-width:0;font-size:.84rem;border:1.5px dashed var(--rpt-border-strong);padding:5px 8px;border-radius:7px;background:var(--rpt-soft);color:var(--rpt-body)}.download-link,.img-preview{align-items:center;white-space:nowrap}.img-preview{display:flex;gap:5px}.img-preview img{width:34px;height:34px;object-fit:cover;border-radius:6px;border:1px solid var(--rpt-border-strong)}.download-link{display:inline-flex;gap:4px;font-size:.8rem;color:var(--rpt-primary-dark);text-decoration:none;padding:4px 10px;border-radius:20px;background:var(--rpt-primary-soft);border:1px solid #d6d1fa;font-weight:700}.ref-toggle-btn,.signoff-check{align-items:center;font-weight:700}.download-link:hover{background:#e2dffc;color:var(--rpt-primary-dark);text-decoration:none}.ref-toggle-btn{display:none;gap:5px;padding:5px 12px;font-size:.78rem;background:var(--rpt-surface);border:1.5px solid var(--rpt-border-strong);border-radius:20px;cursor:pointer;color:var(--rpt-body);transition:.15s}.btn-comment-toggle:hover,.ref-toggle-btn:hover{background:var(--rpt-primary-soft);color:var(--rpt-primary-dark);border-color:var(--rpt-primary)}.ref-toggle-btn i{font-size:.72rem}.category-panel,.signoff-panel{background:var(--rpt-soft);border-top:1px solid var(--rpt-border);padding:10px 12px;display:flex;flex-wrap:wrap;align-items:flex-end;gap:8px 12px}.signoff-group{display:flex;flex-direction:column;gap:3px;flex:1 1 150px;min-width:0}.signoff-group label{font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--rpt-muted)}.signoff-group input,.signoff-group select{width:100%;min-width:0;padding:6px 9px;border:1.5px solid var(--rpt-border-strong);border-radius:7px;font-size:.9rem;color:var(--rpt-ink)!important;font-weight:600;background:var(--rpt-surface)}.signoff-check{display:flex;gap:6px;font-size:.9rem;color:var(--rpt-ink);padding:6px 10px;background:var(--rpt-surface);border:1.5px solid var(--rpt-border-strong);border-radius:7px}.btn-comment-toggle,.test-validation-badge{display:inline-flex;gap:5px;line-height:1.4;white-space:nowrap}.signoff-check input{width:16px;height:16px;accent-color:var(--rpt-primary)}.btn-comment-toggle{padding:5px 13px;font-size:.8rem;border-radius:20px;border:1.5px dashed var(--rpt-border-strong);background:var(--rpt-surface);color:var(--rpt-body);cursor:pointer;transition:.15s;align-items:center;font-weight:700}.btn-comment-toggle.active{background:var(--rpt-primary-soft);color:var(--rpt-primary-dark);border:1.5px solid var(--rpt-primary)}.category-panel{border-top:1px solid var(--rpt-border);background:var(--rpt-soft-2)}.category-panel .signoff-group{min-width:130px;flex:1 1 130px}.category-panel .btn-sm{padding:7px 16px;font-size:.82rem;border-radius:8px;border:none;cursor:pointer;font-weight:700;transition:.15s}.category-panel .btn-apply:hover{background:var(--rpt-primary-dark)}.category-panel .btn-reset{background:var(--rpt-surface);border:1.5px solid var(--rpt-border-strong);color:var(--rpt-body)}.select2-container--default .select2-selection--multiple,.select2-container--default .select2-selection--single{border:1.5px solid var(--rpt-border-strong)!important;border-radius:7px!important;min-height:36px}.select2-container--default.select2-container--focus .select2-selection--multiple,.select2-container--default.select2-container--focus .select2-selection--single{border-color:var(--rpt-primary)!important;box-shadow:0 0 0 3px rgba(115,103,240,.18)}.select2-container--default .select2-selection--single .select2-selection__rendered{color:var(--rpt-ink)!important;font-weight:600;line-height:34px}.select2-container--default .select2-selection--single .select2-selection__placeholder{color:var(--rpt-faint)!important}.select2-dropdown{border-color:var(--rpt-border-strong)!important;box-shadow:var(--rpt-shadow-md)}.select2-results__option{color:var(--rpt-body);font-weight:500}.select2-container--default .select2-results__option--highlighted.select2-results__option--selectable{background:var(--rpt-primary)!important;color:#fff!important}.test-validation-badge{align-items:center;padding:3px 10px;border-radius:12px;font-size:.72rem;font-weight:700;letter-spacing:.2px;margin-left:6px}.test-validation-badge.valid{background:#d1fae5;color:#065f46;border:1px solid #a7f3d0}.test-validation-badge.invalid{background:#fee2e2;color:#991b1b;border:1px solid #fecaca}.test-card.is-invalid{border-left-color:#dc2626!important;box-shadow:inset 0 0 0 2px rgba(220,38,38,.15)}@media (max-width:1200px){.component-table th{font-size:.72rem;padding:7px 6px}.component-table td{padding:4px 6px}.component-table .col-name{width:22%}.component-table .col-result{width:26%}.component-table .col-color,.component-table .col-status,.component-table .col-unit{width:10%}.component-table .col-ref{width:14%}}@media (max-width:992px){.component-table{min-width:720px}.component-table th{font-size:.7rem}.component-table td{font-size:.93rem}.rpt-info-col,.rpt-toolbar{flex:1 1 100%;max-width:100%}.rpt-toolbar{justify-content:flex-start;margin-top:6px}.rpt-search{flex:1 1 auto}.patient-details-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}@media (max-width:768px){.ref-toggle-btn{display:inline-flex}body:not(.show-ref-mobile) .component-table td.col-ref,body:not(.show-ref-mobile) .component-table th.col-ref{display:none!important}.component-table{min-width:560px}.component-table th{font-size:.68rem;padding:6px 5px}.component-table td{padding:4px 5px;font-size:.9rem}.status-input{font-size:.7rem;padding:4px}.color-select{font-size:.62rem}.color-swatch{width:14px;height:14px}.table-input,.table-textarea{font-size:.88rem;padding:5px 7px}.rpt-line,.rpt-sep,.rpt-text{font-size:.95rem}.category-panel,.signoff-panel{flex-direction:column;align-items:stretch;gap:8px;padding:10px}.signoff-group{flex:1 1 100%}.signoff-check{justify-content:flex-start}.img-preview img{width:28px;height:28px}.rpt-header{padding:10px 12px}.rpt-line{gap:4px 8px}.rpt-text{white-space:normal}.rpt-icon{font-size:.84rem}.rpt-toolbar{flex-wrap:wrap;gap:6px;margin-top:6px}.rpt-test-badge{flex:1 1 100%;order:1;padding:5px 10px}.rpt-test-name{font-size:.8rem}.rpt-actions{order:2;flex:1 1 auto}.rpt-btn{flex:1 1 auto;width:auto;min-width:34px}.rpt-search{order:3;flex:1 1 100%;max-width:100%}.patient-details-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:10px 12px}.pd-value{font-size:.86rem}.category-filter-bar{padding:10px;gap:6px}.cat-filter-btn{padding:5px 11px;font-size:.78rem;gap:6px}.cat-filter-btn .cat-name{max-width:110px}.cat-filter-btn .cat-count{min-width:26px;height:18px;font-size:.68rem}.cat-filter-btn .cat-dot{width:7px;height:7px}}@media (max-width:480px){.component-table{min-width:500px}.component-table td,.component-table th{padding:4px;font-size:.86rem}.color-select{font-size:.58rem}.color-swatch{width:12px;height:12px}.hide-check{width:16px;height:16px}.rpt-sep,.rpt-text{font-size:.9rem}.rpt-btn{min-width:30px;height:30px;font-size:.72rem}.patient-details-grid{grid-template-columns:1fr;gap:8px;padding:10px 12px}.pd-item{flex-direction:row;align-items:center;gap:10px}.pd-label{min-width:90px;font-size:.66rem}.pd-value{font-size:.84rem}.cat-filter-btn{font-size:.74rem;padding:5px 9px}.cat-filter-btn .cat-name{max-width:80px}}
   </style>
@endsection

@section('content')
    <section class="invoice-add-wrapper">
        <div class="row invoice-add">
            <div class="col-12">
                <div class="card invoice-preview-card">

                    <div class="card-header rpt-header">
                        <div class="row col-12 m-0">
                            <div class="col-12 col-lg-7 rpt-info-col">
                                <div class="rpt-line">
                                    <span class="rpt-text" id="patient-info">
                                        <i class="fas fa-user rpt-icon"></i>
                                        {{ $receipt->patient->name ?? 'No Patient' }}
                                    </span>

                                    @if (! empty($receipt->patient->age_format))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-birthday-cake rpt-icon"></i>
                                            {{ $receipt->patient->age_format }}
                                        </span>
                                    @endif

                                    @if (! empty($receipt->patient->gender))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-venus-mars rpt-icon"></i>
                                            {{ $receipt->patient->gender }}
                                        </span>
                                    @endif

                                    @if (! empty($receipt->barcode))
                                        <span class="rpt-sep">·</span>
                                        <span class="rpt-text">
                                            <i class="fas fa-barcode rpt-icon"></i>
                                            {{ $receipt->barcode }}
                                        </span>
                                    @endif
                                </div>

                                @if (! empty($receipt->referral?->name))
                                    <div class="rpt-line">
                                        <span class="rpt-text">
                                            <i class="fas fa-user-md rpt-icon"></i>
                                            Ref: {{ $receipt->referral->name }}
                                        </span>
                                        @if (! empty($receipt->referral->designation))
                                            <span class="rpt-sep">·</span>
                                            <span class="rpt-text">{{ $receipt->referral->designation }}</span>
                                        @endif
                                    </div>
                                @endif
                            </div>

                            <div class="col-12 col-lg-5 rpt-toolbar">
                                <div class="rpt-search">
                                    <label class="has-float-label mb-0">
                                        <input type="search"
                                               class="form-control form-control-sm search-receipt"
                                               id="find"
                                               data-redirect="lab/report/bulk-edit/"
                                               autocomplete="off"
                                               title="Lab Receipt No">
                                        <span>Receipt No</span>
                                    </label>
                                </div>

                                <div class="rpt-test-badge">
                                    <span class="rpt-test-name">{{ $stats['total_tests'] ?? 0 }} Tests</span>
                                    <input type="hidden" id="lab_id" value="{{ $receipt->id }}">
                                </div>

                                <div class="rpt-actions">
                                    <a id="headingPatientDetail"
                                       class="rpt-btn rpt-btn-success"
                                       data-toggle="collapse" role="button"
                                       data-target="#viewPatientDetail"
                                       aria-expanded="false" aria-controls="viewPatientDetail"
                                       title="Patient Details">
                                        <i class="fas fa-user"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-info" title="Previous"
                                       href="{{ route('lab.report.bulk.shift', ['id' => $receipt->id, 'd' => 'previous', 'r' => 'bulk']) }}">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-info" title="Next"
                                       href="{{ route('lab.report.bulk.shift', ['id' => $receipt->id, 'd' => 'next', 'r' => 'bulk']) }}">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-primary" title="Single Edit"
                                       href="{{ route('lab.report.edit', $receipt->id) }}">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <a class="rpt-btn rpt-btn-success" title="Combo Edit"
                                       href="{{ route('lab.report.combo.edit', $receipt->id) }}">
                                        <i class="fas fa-th-large"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-content collapse" id="viewPatientDetail" role="tabpanel">
                        <div class="card-body py-0">
                            <div class="patient-details-grid">
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-user"></i> Name</span>
                                    <span class="pd-value">{{ $receipt->patient->name ?? '—' }}</span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-phone-alt"></i> Phone</span>
                                    <span class="pd-value">
                                        @if (! empty($receipt->patient->phone))
                                            <a href="tel:{{ $receipt->patient->phone }}" class="pd-link">{{ $receipt->patient->phone }}</a>
                                        @else — @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-id-card"></i> NID</span>
                                    <span class="pd-value">{{ $receipt->patient->nid_bc ?? '—' }}</span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-birthday-cake"></i> Age</span>
                                    <span class="pd-value">
                                        {{ $receipt->patient->age_format ?? '—' }}
                                        @if (! empty($receipt->patient->dob))
                                            <small class="pd-muted">({{ $receipt->patient->dob }})</small>
                                        @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-venus-mars"></i> Gender</span>
                                    <span class="pd-value">
                                        @if (! empty($receipt->patient->gender))
                                            <span class="pd-chip pd-chip-gender">{{ $receipt->patient->gender }}</span>
                                        @else — @endif
                                    </span>
                                </div>
                                <div class="pd-item">
                                    <span class="pd-label"><i class="fas fa-tint"></i> Blood</span>
                                    <span class="pd-value">
                                        @if (! empty($receipt->patient->blood_group))
                                            <span class="pd-chip pd-chip-blood">{{ $receipt->patient->blood_group }}</span>
                                        @else — @endif
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body py-h">
                        <div class="row"><div class="col-12">
                                <div class="d-flex flex-wrap justify-content-between align-items-center mb-1">
                                    <div class="mb-1">
                                        <span class="badge badge-primary">Total: {{ $stats['total_tests'] ?? 0 }}</span>
                                        <span class="badge badge-success">Completed: {{ $stats['completed_tests'] ?? 0 }}</span>
                                        <span class="badge badge-warning">Pending: {{ $stats['pending_tests'] ?? 0 }}</span>
                                        <span class="badge badge-info">Prepared: {{ $stats['prepared_count'] ?? 0 }}</span>
                                        <span class="badge badge-info">Reviewed: {{ $stats['reviewed_count'] ?? 0 }}</span>
                                        <span class="badge badge-success">Authorized: {{ $stats['authorized_count'] ?? 0 }}</span>
                                    </div>
                                    <div class="no-print top-actions">
                                        <button type="button" class="ref-toggle-btn" onclick="toggleRefColumn(this)">
                                            <i class="fas fa-columns"></i>
                                            <span>Show Reference</span>
                                        </button>
                                        <button type="button" class="hide-all-btn" onclick="toggleAllHide(this)">
                                            <i class="fas fa-eye-slash"></i>
                                            <span>Hide All</span>
                                        </button>
                                        <button class="btn btn-sm btn-success" onclick="saveAll()">
                                            <i class="fas fa-save"></i> Save All
                                        </button>
                                        <button class="btn btn-sm btn-success" onclick="markAllCompleted()">
                                            <i class="fas fa-check-double"></i> Complete All
                                        </button>
                                        <button class="btn btn-sm btn-primary" onclick="batchPrint()">
                                            <i class="fas fa-print"></i> Print All
                                        </button>
                                        <button class="btn btn-sm btn-secondary" onclick="expandAll()">
                                            <i class="fas fa-plus-circle"></i> Expand
                                        </button>
                                        <button class="btn btn-sm btn-secondary" onclick="collapseAll()">
                                            <i class="fas fa-minus-circle"></i> Collapse
                                        </button>
                                    </div>
                                </div>
                                @php
                                    $progress = $stats['total_tests'] > 0
                                        ? ($stats['completed_tests'] / $stats['total_tests']) * 100
                                        : 0;
                                @endphp
                                <div class="progress" style="height:6px;">
                                    <div class="progress-bar" style="width: {{ $progress }}%;"></div>
                                </div>
                                <div class="text-right progress-text">{{ round($progress) }}% Complete</div>
                            </div></div>
                    </div>

                    @if($groupedTests->count())
                        @php
                            $catPalette = [
                                ['#7367f0', '#5b4ddb'],
                                ['#28c76f', '#1fa85a'],
                                ['#ff9f43', '#e88a2e'],
                                ['#00cfe8', '#00a8bd'],
                                ['#ea5455', '#c93e3f'],
                                ['#ff6b9d', '#e0507d'],
                                ['#f59e0b', '#d97706'],
                                ['#8b5cf6', '#7c3aed'],
                                ['#0ea5e9', '#0284c7'],
                                ['#10b981', '#059669'],
                            ];
                            $ci = 0;
                        @endphp

                        <div class="category-filter-bar">
                            <button type="button" class="cat-filter-btn cat-all active" data-category="__all__"
                                    style="--cat-a: #7367f0; --cat-b: #5b4ddb;">
                                <i class="fas fa-layer-group"></i>
                                <span class="cat-name">All</span>
                                <span class="cat-count">{{ $stats['total_tests'] ?? 0 }}</span>
                            </button>

                            @foreach($groupedTests as $category => $tests)
                                @php
                                    $doneCat  = $tests->where('done', 1)->count();
                                    $totalCat = $tests->count();
                                    $isDone   = $totalCat > 0 && $doneCat === $totalCat;
                                    $pal      = $catPalette[$ci % count($catPalette)];
                                    $ci++;
                                @endphp
                                <button type="button"
                                        class="cat-filter-btn {{ $isDone ? 'is-done' : '' }}"
                                        data-category="{{ $category }}"
                                        style="--cat-a: {{ $pal[0] }}; --cat-b: {{ $pal[1] }};">
                                    <span class="cat-dot"></span>
                                    <span class="cat-name">{{ $category }}</span>
                                    <span class="cat-count">{{ $doneCat }}/{{ $totalCat }}</span>
                                </button>
                            @endforeach
                        </div>
                    @endif

                    <div class="card-content">
                        <form id="bulk-form" action="{{ route('lab.report.bulk.update.receipt') }}" method="post"
                              enctype="multipart/form-data" autocomplete="off">
                            @csrf
                            <input type="hidden" name="receipt_id" value="{{ $receipt->id }}">

                            <div class="card-body mt-0 pt-0">
                                @if($groupedTests->count())
                                    @php $globalTestIndex = 0; @endphp
                                    @foreach($groupedTests as $category => $tests)
                                        <div class="card card-primary mt-1 category-container" data-category="{{ $category }}">
                                            <div class="card-header py-h category-header">
                                                <div class="row col-12">
                                                    <div class="col-12 col-md-6" onclick="toggleCategory(this)" style="cursor:pointer;">
                                                        <h5 class="mb-0">
                                                            <i class="fas fa-folder"></i> {{ $category }}
                                                            <span class="badge badge-primary">{{ $tests->count() }}</span>
                                                            @php
                                                                $doneCat = $tests->where('done', 1)->count();
                                                                $pct = $tests->count() > 0 ? round(($doneCat / $tests->count()) * 100) : 0;
                                                            @endphp
                                                            <span class="badge badge-{{ $pct == 100 ? 'success' : 'warning' }}">
                                                                {{ $doneCat }}/{{ $tests->count() }}
                                                            </span>
                                                        </h5>
                                                    </div>
                                                    <div class="col-12 col-md-6 text-right">
                                                        <div class="actions-wrapper justify-content-end">
                                                            <div class="category-actions">
                                                                <button type="button" class="btn btn-sm category-save-btn"
                                                                        onclick="saveCategory(this, '{{ $category }}')" title="Save Category">
                                                                    <i class="fas fa-save"></i>
                                                                </button>
                                                                <button type="button" class="btn btn-sm category-complete-btn"
                                                                        onclick="completeCategory(this, '{{ $category }}')" title="Complete Category">
                                                                    <i class="fas fa-check-double"></i>
                                                                </button>
                                                                <button type="button" class="btn btn-sm category-print-btn"
                                                                        onclick="printCategory('{{ $category }}')" title="Print Category">
                                                                    <i class="fas fa-print"></i>
                                                                </button>
                                                                <button type="button" class="btn btn-sm btn-secondary"
                                                                        onclick="toggleCategory(this.closest('.category-header'))">
                                                                    <i class="fas fa-chevron-up toggle-icon"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card-body p-0 category-content">
                                                @foreach($tests as $test)
                                                    @php
                                                        $tConfig      = $test->test?->config;
                                                        $tShowStatus  = (bool) ($tConfig?->show_status ?? false);
                                                        $tShowColor   = (bool) ($tConfig?->result_color ?? false);
                                                        $tShowMic     = (bool) ($tConfig?->culture_show_mic ?? false);
                                                        $tShowZone    = (bool) ($tConfig?->culture_show_zone ?? false);
                                                        $tTailColspan = 3 + ($tShowStatus ? 1 : 0) + ($tShowColor ? 1 : 0);
                                                        $tTotalCols   = 6 + ($tShowStatus ? 1 : 0) + ($tShowColor ? 1 : 0);
                                                        $tTableClass  = 'component-table'
                                                                      . ($tShowStatus ? '' : ' no-status')
                                                                      . ($tShowColor ? '' : ' no-color');
                                                        $customJsKey  = $tConfig?->custom_js;
                                                    @endphp
                                                    <div class="card card-primary m-1 test-card {{ $test->done ? 'completed' : 'pending' }}"
                                                         data-test-id="{{ $test->id }}"
                                                         data-test-name="{{ $test->test->name ?? '' }}"
                                                         @if($customJsKey) data-custom-js="{{ $customJsKey }}" @endif>
                                                        <div class="card-body p-0">
                                                            <div class="py-h px-2 test-header" style="cursor:pointer;" onclick="toggleTest(this)">
                                                                <div class="row">
                                                                    <div class="col-12 col-md-8">
                                                                        <b>{{ $loop->iteration }}) {{ $test->test->name ?? 'Unknown' }}</b>
                                                                        <span class="text-muted">({{ $test->test->short_name ?? '' }})</span>
                                                                        <span class="badge {{ $test->done ? 'badge-success' : 'badge-warning' }}">
                                                                            {{ $test->done ? '✓ Completed' : '⏳ Pending' }}
                                                                        </span>
                                                                        @if($test->prepared_at)<span class="badge badge-warning">P</span>@endif
                                                                        @if($test->reviewed_at)<span class="badge badge-info">R</span>@endif
                                                                        @if($test->authorized_at)<span class="badge badge-success">A</span>@endif
                                                                        <span class="test-validation-badge" style="display:none;"></span>
                                                                    </div>
                                                                    <div class="col-12 col-md-4 text-right">
                                                                        <i class="fas fa-chevron-down toggle-icon-sm"></i>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <input type="hidden" name="tests[{{ $globalTestIndex }}][id]" value="{{ $test->id }}">
                                                            <input type="hidden" name="tests[{{ $globalTestIndex }}][complete]"
                                                                   value="{{ $test->done ? 1 : 0 }}"
                                                                   class="test-complete"
                                                                   data-test-id="{{ $test->id }}">

                                                            <div class="test-details">
                                                                <div class="component-wrap">
                                                                    <table class="{{ $tTableClass }}">
                                                                        <thead>
                                                                        <tr>
                                                                            <th class="col-sl">SL</th>
                                                                            <th class="col-hide"><i class="fas fa-eye-slash"></i></th>
                                                                            <th class="col-name">Component</th>
                                                                            <th class="col-result">Result</th>
                                                                            <th class="col-unit">Unit</th>
                                                                            <th class="col-ref">Reference</th>
                                                                            @if($tShowStatus)<th class="col-status">Status</th>@endif
                                                                            @if($tShowColor)<th class="col-color">Color</th>@endif
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                        @php $currentTitleId = null; @endphp

                                                                        @if($test->components && $test->components->count())
                                                                            @foreach($test->components as $comp)
                                                                                <input type="hidden" name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][id]" value="{{ $comp->report_id ?? '' }}">
                                                                                <input type="hidden" name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][component_id]" value="{{ $comp->id }}">
                                                                                <input type="hidden" name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][type]" value="{{ $comp->type ?? '' }}">
                                                                                <input type="hidden" name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][unit]" value="{{ $comp->unit ?? '' }}">

                                                                                @if($comp->type == 'title')
                                                                                    @php $currentTitleId = 'title-' . $test->id . '-' . $comp->id; @endphp
                                                                                    <tr class="row-title"
                                                                                        data-title-id="{{ $currentTitleId }}"
                                                                                        data-component-id="{{ $comp->id }}">
                                                                                        <td class="col-sl"></td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-check-title" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hide) checked @endif value="1"
                                                                                                   onchange="handleTitleHideChange(this)">
                                                                                        </td>
                                                                                        <td colspan="{{ $tTotalCols - 2 }}">
                                                                                            <b>{{ $comp->name }}</b>
                                                                                        </td>
                                                                                    </tr>

                                                                                @elseif($comp->type == 'number')
                                                                                    <tr class="component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result">
                                                                                            <input type="text" class="table-input component-value changeStatus"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result]"
                                                                                                   value="{{ $comp->result ?? '' }}" autocomplete="off">
                                                                                        </td>
                                                                                        <td class="col-unit">
                                                                                            <input type="text" class="table-input"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][unit]"
                                                                                                   value="{{ $comp->unit ?? '' }}" placeholder="Unit">
                                                                                        </td>
                                                                                        <td class="col-ref">
                                                                                            @if(!empty($comp->available_references))
                                                                                                <div class="ref-picker" data-ref-picker>
                                                                                                    <input type="hidden"
                                                                                                           class="ref-hidden"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                           value="{{ $comp->reference_text ?? '' }}">
                                                                                                    <span class="ref-text ref-display"
                                                                                                          title="Click to change reference"
                                                                                                          onclick="openRefSelect(this)">
                                                                                                        {{ $comp->reference_text ?: '—' }}
                                                                                                    </span>
                                                                                                    <select class="ref-select ref-editor"
                                                                                                            style="display:none;"
                                                                                                            onchange="applyRefSelect(this)"
                                                                                                            onblur="closeRefSelect(this)">
                                                                                                        <option value="">—</option>
                                                                                                        @foreach($comp->available_references as $ref)
                                                                                                            <option value="{{ $ref }}"
                                                                                                                @selected($comp->reference_text === $ref)>
                                                                                                                {{ $ref }}
                                                                                                            </option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                </div>
                                                                                            @elseif($comp->reference_text)
                                                                                                <input type="hidden"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                       value="{{ $comp->reference_text }}">
                                                                                                <span class="ref-text">{{ $comp->reference_text }}</span>
                                                                                            @endif
                                                                                        </td>
                                                                                        @if($tShowStatus)
                                                                                            <td class="col-status">
                                                                                                <input type="text" class="status-input"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][status]"
                                                                                                       value="{{ $comp->status ?? '' }}" list="status-list" placeholder="—">
                                                                                            </td>
                                                                                        @endif
                                                                                        @if($tShowColor)
                                                                                            <td class="col-color">
                                                                                                <div class="color-cell-wrap">
                                                                                                    <span class="color-swatch {{ $comp->color ? '' : 'empty' }}"
                                                                                                          style="{{ $comp->color ? 'background:#'.$comp->color : '' }}"></span>
                                                                                                    <select class="color-select"
                                                                                                            name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][color]"
                                                                                                            onchange="updateColorPreview(this)">
                                                                                                        <option value="" {{ !$comp->color ? 'selected' : '' }}>—</option>
                                                                                                        <option value="28c76f" {{ $comp->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                                        <option value="ea5455" {{ $comp->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                                        <option value="ff9f43" {{ $comp->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                                        <option value="ffd93d" {{ $comp->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                                        <option value="00cfe8" {{ $comp->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                                        <option value="7367f0" {{ $comp->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                                        <option value="ff6b9d" {{ $comp->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                                        <option value="a0a3b1" {{ $comp->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </td>
                                                                                        @endif
                                                                                    </tr>

                                                                                @elseif($comp->type == 'select' || $comp->type == 'pattern')
                                                                                    <tr class="component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result" colspan="2">
                                                                                            <input type="search" class="table-input component-value dynamic-input"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result]"
                                                                                                   value="{{ $comp->result ?? '' }}" autocomplete="off"
                                                                                                   data-dynamic="id" data-id="{{ $comp->id }}"
                                                                                                   multiple data-multiple="true"
                                                                                                   data-key="option_value" data-value="option_value"
                                                                                                   data-table="test_components"
                                                                                                   data-url="ajax/get-option-separate">
                                                                                        </td>
                                                                                        <td class="col-ref">
                                                                                            @if(!empty($comp->available_references))
                                                                                                <div class="ref-picker" data-ref-picker>
                                                                                                    <input type="hidden"
                                                                                                           class="ref-hidden"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                           value="{{ $comp->reference_text ?? '' }}">
                                                                                                    <span class="ref-text ref-display"
                                                                                                          title="Click to change reference"
                                                                                                          onclick="openRefSelect(this)">
                                                                                                        {{ $comp->reference_text ?: '—' }}
                                                                                                    </span>
                                                                                                    <select class="ref-select ref-editor"
                                                                                                            style="display:none;"
                                                                                                            onchange="applyRefSelect(this)"
                                                                                                            onblur="closeRefSelect(this)">
                                                                                                        <option value="">—</option>
                                                                                                        @foreach($comp->available_references as $ref)
                                                                                                            <option value="{{ $ref }}"
                                                                                                                @selected($comp->reference_text === $ref)>
                                                                                                                {{ $ref }}
                                                                                                            </option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                </div>
                                                                                            @elseif($comp->reference_text)
                                                                                                <input type="hidden"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                       value="{{ $comp->reference_text }}">
                                                                                                <span class="ref-text">{{ $comp->reference_text }}</span>
                                                                                            @endif
                                                                                        </td>
                                                                                        @if($tShowStatus)
                                                                                            <td class="col-status">
                                                                                                <input type="text" class="status-input"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][status]"
                                                                                                       value="{{ $comp->status ?? '' }}" list="status-list" placeholder="—">
                                                                                            </td>
                                                                                        @endif
                                                                                        @if($tShowColor)
                                                                                            <td class="col-color">
                                                                                                <div class="color-cell-wrap">
                                                                                                    <span class="color-swatch {{ $comp->color ? '' : 'empty' }}"
                                                                                                          style="{{ $comp->color ? 'background:#'.$comp->color : '' }}"></span>
                                                                                                    <select class="color-select"
                                                                                                            name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][color]"
                                                                                                            onchange="updateColorPreview(this)">
                                                                                                        <option value="" {{ !$comp->color ? 'selected' : '' }}>—</option>
                                                                                                        <option value="28c76f" {{ $comp->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                                        <option value="ea5455" {{ $comp->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                                        <option value="ff9f43" {{ $comp->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                                        <option value="ffd93d" {{ $comp->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                                        <option value="00cfe8" {{ $comp->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                                        <option value="7367f0" {{ $comp->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                                        <option value="ff6b9d" {{ $comp->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                                        <option value="a0a3b1" {{ $comp->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </td>
                                                                                        @endif
                                                                                    </tr>

                                                                                @elseif($comp->type == 'text')
                                                                                    <tr class="component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result" colspan="2">
                                                                                            <input type="search" class="table-input component-value dynamic-input"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result]"
                                                                                                   value="{{ $comp->result ?? '' }}" autocomplete="off"
                                                                                                   data-dynamic="test_id,component_id"
                                                                                                   data-test_id="{{ $comp->test_id ?? '' }}"
                                                                                                   data-component_id="{{ $comp->id ?? '' }}"
                                                                                                   data-key="result" data-value="result"
                                                                                                   data-table="test_reports"
                                                                                                   data-url="ajax/get-dynamic-option">
                                                                                        </td>
                                                                                        <td class="col-ref">
                                                                                            @if(!empty($comp->available_references))
                                                                                                <div class="ref-picker" data-ref-picker>
                                                                                                    <input type="hidden"
                                                                                                           class="ref-hidden"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                           value="{{ $comp->reference_text ?? '' }}">
                                                                                                    <span class="ref-text ref-display"
                                                                                                          title="Click to change reference"
                                                                                                          onclick="openRefSelect(this)">
                                                                                                        {{ $comp->reference_text ?: '—' }}
                                                                                                    </span>
                                                                                                    <select class="ref-select ref-editor"
                                                                                                            style="display:none;"
                                                                                                            onchange="applyRefSelect(this)"
                                                                                                            onblur="closeRefSelect(this)">
                                                                                                        <option value="">—</option>
                                                                                                        @foreach($comp->available_references as $ref)
                                                                                                            <option value="{{ $ref }}"
                                                                                                                @selected($comp->reference_text === $ref)>
                                                                                                                {{ $ref }}
                                                                                                            </option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                </div>
                                                                                            @elseif($comp->reference_text)
                                                                                                <input type="hidden"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                       value="{{ $comp->reference_text }}">
                                                                                                <span class="ref-text">{{ $comp->reference_text }}</span>
                                                                                            @endif
                                                                                        </td>
                                                                                        @if($tShowStatus)
                                                                                            <td class="col-status">
                                                                                                <input type="text" class="status-input"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][status]"
                                                                                                       value="{{ $comp->status ?? '' }}" list="status-list" placeholder="—">
                                                                                            </td>
                                                                                        @endif
                                                                                        @if($tShowColor)
                                                                                            <td class="col-color">
                                                                                                <div class="color-cell-wrap">
                                                                                                    <span class="color-swatch {{ $comp->color ? '' : 'empty' }}"
                                                                                                          style="{{ $comp->color ? 'background:#'.$comp->color : '' }}"></span>
                                                                                                    <select class="color-select"
                                                                                                            name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][color]"
                                                                                                            onchange="updateColorPreview(this)">
                                                                                                        <option value="" {{ !$comp->color ? 'selected' : '' }}>—</option>
                                                                                                        <option value="28c76f" {{ $comp->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                                        <option value="ea5455" {{ $comp->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                                        <option value="ff9f43" {{ $comp->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                                        <option value="ffd93d" {{ $comp->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                                        <option value="00cfe8" {{ $comp->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                                        <option value="7367f0" {{ $comp->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                                        <option value="ff6b9d" {{ $comp->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                                        <option value="a0a3b1" {{ $comp->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </td>
                                                                                        @endif
                                                                                    </tr>

                                                                                @elseif($comp->type == 'culture')
                                                                                    @php
                                                                                        /* resolved value vs no report-frozen value → italic */
                                                                                        $micIsDefault  = ! empty($comp->mic_value)  && empty($comp->report_id ? $comp->mic_value : null) === false
                                                                                                        ? false : ! empty($comp->mic_value);
                                                                                        /* simpler: italic only when no report_id (never saved) but resolved value exists */
                                                                                        $micIsDefault  = empty($comp->report_id) && ! empty($comp->mic_value);
                                                                                        $zoneIsDefault = empty($comp->report_id) && ! empty($comp->zone_value);
                                                                                    @endphp
                                                                                    <tr class="component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>

                                                                                        <td class="col-name">{{ $comp->name }}</td>

                                                                                        <td class="col-result" colspan="2">
                                                                                            <div class="culture-input-group">
                                                                                                @if($tShowMic)
                                                                                                    <input type="text"
                                                                                                           class="table-input culture-mic {{ $micIsDefault ? 'is-default' : '' }}"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][mic_value]"
                                                                                                           value="{{ old('tests.'.$globalTestIndex.'.components.'.$comp->id.'.mic_value', $comp->mic_value ?? '') }}"
                                                                                                           placeholder="MIC" autocomplete="off">
                                                                                                @endif

                                                                                                @if($tShowZone)
                                                                                                    <input type="text"
                                                                                                           class="table-input culture-zone {{ $zoneIsDefault ? 'is-default' : '' }}"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][zone_value]"
                                                                                                           value="{{ old('tests.'.$globalTestIndex.'.components.'.$comp->id.'.zone_value', $comp->zone_value ?? '') }}"
                                                                                                           placeholder="Zone" autocomplete="off">
                                                                                                @endif

                                                                                                <select class="culture-interp interp-{{ strtolower($comp->result ?? 'nt') }}"
                                                                                                        name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result]"
                                                                                                        onchange="styleInterpSelect(this)">
                                                                                                    <option value=""   {{ !$comp->result       ? 'selected' : '' }}>—</option>
                                                                                                    <option value="S"  {{ $comp->result === 'S' ? 'selected' : '' }}>S</option>
                                                                                                    <option value="I"  {{ $comp->result === 'I' ? 'selected' : '' }}>I</option>
                                                                                                    <option value="R"  {{ $comp->result === 'R' ? 'selected' : '' }}>R</option>
                                                                                                    <option value="NT" {{ $comp->result === 'NT'? 'selected' : '' }}>NT</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </td>

                                                                                        <td class="col-ref">
                                                                                            @if(!empty($comp->available_references))
                                                                                                <div class="ref-picker" data-ref-picker>
                                                                                                    <input type="hidden"
                                                                                                           class="ref-hidden"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                           value="{{ $comp->reference_text ?? '' }}">
                                                                                                    <span class="ref-text ref-display"
                                                                                                          title="Click to change reference"
                                                                                                          onclick="openRefSelect(this)">
                                                                                                        {{ $comp->reference_text ?: '—' }}
                                                                                                    </span>
                                                                                                    <select class="ref-select ref-editor"
                                                                                                            style="display:none;"
                                                                                                            onchange="applyRefSelect(this)"
                                                                                                            onblur="closeRefSelect(this)">
                                                                                                        <option value="">—</option>
                                                                                                        @foreach($comp->available_references as $ref)
                                                                                                            <option value="{{ $ref }}"
                                                                                                                @selected($comp->reference_text === $ref)>
                                                                                                                {{ $ref }}
                                                                                                            </option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                </div>
                                                                                            @elseif($comp->reference_text)
                                                                                                <input type="hidden"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                       value="{{ $comp->reference_text }}">
                                                                                                <span class="ref-text">{{ $comp->reference_text }}</span>
                                                                                            @endif
                                                                                        </td>

                                                                                        @if($tShowStatus)
                                                                                            <td class="col-status">
                                                                                                <input type="text" class="status-input"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][status]"
                                                                                                       value="{{ $comp->status ?? '' }}" list="status-list" placeholder="—">
                                                                                            </td>
                                                                                        @endif

                                                                                        @if($tShowColor)
                                                                                            <td class="col-color">
                                                                                                <div class="color-cell-wrap">
                                                                                                    <span class="color-swatch {{ $comp->color ? '' : 'empty' }}"
                                                                                                          style="{{ $comp->color ? 'background:#'.$comp->color : '' }}"></span>
                                                                                                    <select class="color-select"
                                                                                                            name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][color]"
                                                                                                            onchange="updateColorPreview(this)">
                                                                                                        <option value=""      {{ !$comp->color ? 'selected' : '' }}>—</option>
                                                                                                        <option value="28c76f" {{ $comp->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                                        <option value="ea5455" {{ $comp->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                                        <option value="ff9f43" {{ $comp->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                                        <option value="ffd93d" {{ $comp->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                                        <option value="00cfe8" {{ $comp->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                                        <option value="7367f0" {{ $comp->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                                        <option value="ff6b9d" {{ $comp->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                                        <option value="a0a3b1" {{ $comp->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </td>
                                                                                        @endif
                                                                                    </tr>

                                                                                @elseif($comp->type == 'textarea')
                                                                                    <tr class="row-full component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result-full" colspan="{{ $tTailColspan }}">
                                                                                            <textarea class="table-textarea component-value" rows="2"
                                                                                                      name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result_text]">{{ $comp->result_text ?? $comp->result ?? '' }}</textarea>
                                                                                        </td>
                                                                                    </tr>

                                                                                @elseif($comp->type == 'file')
                                                                                    <tr class="row-full component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result-full" colspan="{{ $tTailColspan }}">
                                                                                            <div class="file-upload-inline">
                                                                                                <input type="file" class="file-input"
                                                                                                       id="{{ $loop->iteration }}_file_"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result_file]"
                                                                                                       @if($comp->default_value == 'image') accept="image/*" @else accept="application/pdf" @endif
                                                                                                       onchange="handleFileChange(this)">
                                                                                                @if($comp->document)
                                                                                                    <a href="{{ $comp->document }}" class="download-link" target="_blank">
                                                                                                        <i class="fas fa-download"></i> Download
                                                                                                    </a>
                                                                                                @endif
                                                                                            </div>
                                                                                        </td>
                                                                                    </tr>

                                                                                @else
                                                                                    <tr class="component-row"
                                                                                        data-component-id="{{ $comp->id }}"
                                                                                        data-parent-title="{{ $currentTitleId }}">
                                                                                        <td class="col-sl">{{ $loop->iteration }}</td>
                                                                                        <td class="col-hide">
                                                                                            <input class="hide-check hide-checkbox" type="checkbox"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][hide]"
                                                                                                   @if($comp->hidden ?? false) checked @endif value="1"
                                                                                                   onchange="handleHideCheckboxChange(this)">
                                                                                        </td>
                                                                                        <td class="col-name">{{ $comp->name }}</td>
                                                                                        <td class="col-result" colspan="2">
                                                                                            <input type="text" class="table-input component-value"
                                                                                                   name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][result]"
                                                                                                   value="{{ $comp->result ?? '' }}">
                                                                                        </td>
                                                                                        <td class="col-ref">
                                                                                            @if(!empty($comp->available_references))
                                                                                                <div class="ref-picker" data-ref-picker>
                                                                                                    <input type="hidden"
                                                                                                           class="ref-hidden"
                                                                                                           name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                           value="{{ $comp->reference_text ?? '' }}">
                                                                                                    <span class="ref-text ref-display"
                                                                                                          title="Click to change reference"
                                                                                                          onclick="openRefSelect(this)">
                                                                                                        {{ $comp->reference_text ?: '—' }}
                                                                                                    </span>
                                                                                                    <select class="ref-select ref-editor"
                                                                                                            style="display:none;"
                                                                                                            onchange="applyRefSelect(this)"
                                                                                                            onblur="closeRefSelect(this)">
                                                                                                        <option value="">—</option>
                                                                                                        @foreach($comp->available_references as $ref)
                                                                                                            <option value="{{ $ref }}"
                                                                                                                @selected($comp->reference_text === $ref)>
                                                                                                                {{ $ref }}
                                                                                                            </option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                </div>
                                                                                            @elseif($comp->reference_text)
                                                                                                <input type="hidden"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][reference_text]"
                                                                                                       value="{{ $comp->reference_text }}">
                                                                                                <span class="ref-text">{{ $comp->reference_text }}</span>
                                                                                            @endif
                                                                                        </td>
                                                                                        @if($tShowStatus)
                                                                                            <td class="col-status">
                                                                                                <input type="text" class="status-input"
                                                                                                       name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][status]"
                                                                                                       value="{{ $comp->status ?? '' }}" list="status-list" placeholder="—">
                                                                                            </td>
                                                                                        @endif
                                                                                        @if($tShowColor)
                                                                                            <td class="col-color">
                                                                                                <div class="color-cell-wrap">
                                                                                                    <span class="color-swatch {{ $comp->color ? '' : 'empty' }}"
                                                                                                          style="{{ $comp->color ? 'background:#'.$comp->color : '' }}"></span>
                                                                                                    <select class="color-select"
                                                                                                            name="tests[{{ $globalTestIndex }}][components][{{ $comp->id }}][color]"
                                                                                                            onchange="updateColorPreview(this)">
                                                                                                        <option value="" {{ !$comp->color ? 'selected' : '' }}>—</option>
                                                                                                        <option value="28c76f" {{ $comp->color == '28c76f' ? 'selected' : '' }}>Normal</option>
                                                                                                        <option value="ea5455" {{ $comp->color == 'ea5455' ? 'selected' : '' }}>Critical</option>
                                                                                                        <option value="ff9f43" {{ $comp->color == 'ff9f43' ? 'selected' : '' }}>Warning</option>
                                                                                                        <option value="ffd93d" {{ $comp->color == 'ffd93d' ? 'selected' : '' }}>Caution</option>
                                                                                                        <option value="00cfe8" {{ $comp->color == '00cfe8' ? 'selected' : '' }}>Info</option>
                                                                                                        <option value="7367f0" {{ $comp->color == '7367f0' ? 'selected' : '' }}>Special</option>
                                                                                                        <option value="ff6b9d" {{ $comp->color == 'ff6b9d' ? 'selected' : '' }}>Note</option>
                                                                                                        <option value="a0a3b1" {{ $comp->color == 'a0a3b1' ? 'selected' : '' }}>Neutral</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </td>
                                                                                        @endif
                                                                                    </tr>
                                                                                @endif
                                                                            @endforeach
                                                                        @endif
                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                                <div class="signoff-panel">
                                                                    <div class="signoff-group">
                                                                        <label>Prepared By</label>
                                                                        <select class="dynamic-select select2"
                                                                                name="tests[{{ $globalTestIndex }}][prepared_by]"
                                                                                data-placeholder="Prepared By" data-container="select-sm"
                                                                                data-tenant="true" data-table="users"
                                                                                data-value="id" data-column_names="name,phone,code"
                                                                                data-multi_value="name,code" data-key="id"
                                                                                data-url="ajax/get-dynamic-option">
                                                                            @if($test->prepared)
                                                                                <option value="{{ $test->prepared->id }}" selected>{{ $test->prepared->name }}</option>
                                                                            @else
                                                                                <option value="">Select</option>
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                    <div class="signoff-group">
                                                                        <label>Reviewed By</label>
                                                                        <select class="dynamic-select select2"
                                                                                name="tests[{{ $globalTestIndex }}][reviewed_by]"
                                                                                data-placeholder="Reviewed By" data-container="select-sm"
                                                                                data-tenant="true" data-table="users"
                                                                                data-value="id" data-column_names="name,phone,code"
                                                                                data-multi_value="name,phone,code" data-key="id"
                                                                                data-url="ajax/get-dynamic-option">
                                                                            @if($test->reviewed)
                                                                                <option value="{{ $test->reviewed->id }}" selected>{{ $test->reviewed->name }}</option>
                                                                            @else
                                                                                <option value="">Select</option>
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                    <div class="signoff-group">
                                                                        <label>Authorized By</label>
                                                                        <select class="dynamic-select select2"
                                                                                name="tests[{{ $globalTestIndex }}][authorized_by]"
                                                                                data-placeholder="Authorized By" data-container="select-sm"
                                                                                data-tenant="true" data-table="users"
                                                                                data-value="id" data-column_names="name,phone,code"
                                                                                data-multi_value="name,phone,code" data-key="id"
                                                                                data-url="ajax/get-dynamic-option">
                                                                            @if($test->authorized)
                                                                                <option value="{{ $test->authorized->id }}" selected>{{ $test->authorized->name }}</option>
                                                                            @else
                                                                                <option value="">Select</option>
                                                                            @endif
                                                                        </select>
                                                                    </div>

                                                                    <div class="signoff-group comment-group"
                                                                         @if(empty($test->comment)) style="display:none;" @endif>
                                                                        <label>Comment</label>
                                                                        <input type="text" name="tests[{{ $globalTestIndex }}][comment]"
                                                                               value="{{ $test->comment ?? '' }}" placeholder="Optional note">
                                                                    </div>
                                                                    <div class="signoff-group comment-toggle-group" style="flex:0 0 auto; min-width:0;">
                                                                        <label>&nbsp;</label>
                                                                        <button type="button"
                                                                                class="btn-comment-toggle {{ !empty($test->comment) ? 'active' : '' }}"
                                                                                onclick="toggleTestComment(this)">
                                                                            <i class="fas fa-comment"></i>
                                                                            <span>{{ !empty($test->comment) ? 'Hide' : 'Add' }} Comment</span>
                                                                        </button>
                                                                    </div>

                                                                    <div class="signoff-check">
                                                                        <input class="test-complete-chk" type="checkbox"
                                                                               data-id="{{ $test->id }}"
                                                                               {{ $test->done ? 'checked' : '' }}
                                                                               onchange="toggleComplete(this, '{{ $test->id }}')">
                                                                        <label style="margin:0; text-transform:none;">Report is Completed</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @php $globalTestIndex++; @endphp
                                                @endforeach

                                                <div class="category-panel" data-category="{{ $category }}">
                                                    <div class="signoff-group">
                                                        <label>Prepared By</label>
                                                        <select class="dynamic-select select2 category-prepared-by"
                                                                data-placeholder="Prepared By" data-container="select-sm"
                                                                data-tenant="true" data-table="users"
                                                                data-value="id" data-column_names="name,phone,code"
                                                                data-multi_value="name,code" data-key="id"
                                                                data-url="ajax/get-dynamic-option">
                                                            <option value="">Select</option>
                                                        </select>
                                                    </div>
                                                    <div class="signoff-group">
                                                        <label>Reviewed By</label>
                                                        <select class="dynamic-select select2 category-reviewed-by"
                                                                data-placeholder="Reviewed By" data-container="select-sm"
                                                                data-tenant="true" data-table="users"
                                                                data-value="id" data-column_names="name,phone,code"
                                                                data-multi_value="name,phone,code" data-key="id"
                                                                data-url="ajax/get-dynamic-option">
                                                            <option value="">Select</option>
                                                        </select>
                                                    </div>
                                                    <div class="signoff-group">
                                                        <label>Authorized By</label>
                                                        <select class="dynamic-select select2 category-authorized-by"
                                                                data-placeholder="Authorized By" data-container="select-sm"
                                                                data-tenant="true" data-table="users"
                                                                data-value="id" data-column_names="name,phone,code"
                                                                data-multi_value="name,phone,code" data-key="id"
                                                                data-url="ajax/get-dynamic-option">
                                                            <option value="">Select</option>
                                                        </select>
                                                    </div>
                                                    <button type="button" class="btn-sm btn-apply"
                                                            onclick="applyCategorySignoff('{{ $category }}')">
                                                        <i class="fas fa-check"></i> Apply to all
                                                    </button>
                                                    <button type="button" class="btn-sm btn-reset"
                                                            onclick="resetCategorySignoff('{{ $category }}')">
                                                        <i class="fas fa-undo"></i> Reset
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @else
                                    <h6 class="text-center">{{ __('No data available') }}</h6>
                                @endif
                            </div>

                            <div class="card-footer row" style="background:var(--rpt-soft); border-top:1px solid var(--rpt-border);">
                                <div class="form-group text-center col-12 col-sm-12 col-md-6 col-xl-6 mx-auto">
                                    <button class="btn btn-primary mr-1 submit-btn" type="button" onclick="saveAll()"
                                            style="background:var(--rpt-primary); border-color:var(--rpt-primary); border-radius:22px; font-weight:700; padding:.5rem 1.4rem;">
                                        <i class="fas fa-save"></i> Save All
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary"
                                            style="border-radius:22px; font-weight:600; padding:.5rem 1.2rem;"
                                            onclick="window.location.reload();">
                                        <i class="fas fa-redo"></i> Reload
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <datalist id="status-list">
        <option value="Normal"><option value="High"><option value="Low">
        <option value="Abnormal"><option value="Critical"><option value="Info">
        <option value="Pending">
    </datalist>

    <div class="save-indicator" id="saveInd">
        <div class="alert alert-success" id="saveMsg"
             style="display:none; position:fixed; bottom:20px; right:20px; z-index:9999; padding:10px 18px;">
            <i class="fas fa-spinner fa-spin"></i> Saving...
        </div>
    </div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/pages/lab-report.js')) }}"></script>
    <script src="{{ asset(mix('js/scripts/pages/test-custom-function.js')) }}"></script>
    <script src="{{ asset(mix('/vendors/js/bookmark-editor/bookmark-manager.js')) }}"></script>
    <script src="{{ asset(mix('js/scripts/pages/dynamic.min.js')) }}"></script>
@endsection
